﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace L8F.MyInterfaces
{
    /**
     * Interfata pentru threaduri
     * --------------------------
     * Orice thread care comunica cu un thread din aceasta interfata va putea
     * actualiza variabila updated.
     * ----------------------------
     * Conform cu specificul cerintei, am inclus si o metoda de actualizare a
     * interfetei grafice cu utilizatorul.
     */
    interface ThreadClient
    {
        /**
         * Metoda Run
         * ----------
         * Este metoda care ruleaza cand threadul este pornit.
         */
        void Run();

        /**
         * Metoda UpdateGUI
         * ----------------
         * Este metoda apelata din Run ori de cate ori este necesara 
         * actualizarea interfetei cu utilizatorul.
         */
        void UpdateGUI();

        /**
         * Obiectul updated
         * ----------------
         * Este obiectul actualizat din exterior pe care threadul il citeste.
         * Spre exemplu, daca au venit date, atunci acest obiect devine true
         * si este resetat pe false cand threadul a aflat acest lucru.
         * -----------------------------------------------------------
         * Bineinteles, acest obiect trebuie implementat thread-safe!
         */
        Object Updated
        {
            // getter
            get;
            
            // setter
            set;
        }

        /**
         * Obiectul exists
         * ---------------
         * Este raspunsul daca exista elemente in update
         */
        bool Exists
        {
            // getter
            get;
        }
    }
}
