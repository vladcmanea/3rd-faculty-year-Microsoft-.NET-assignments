﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace L8F.MyData
{
    /**
     * Clasa ListVowels
     * ----------------
     * Retine si lucreaza cu o lista de vocale
     */
    public class ListVowels
    {
        /**
         * Obiectul locked
         * ---------------
         * Un obiect blocabil pentru thread-safety
         */
        private readonly Object locked = new Object();

        /**
         * Dictionarul vowels
         * ------------------
         * Permite stocarea vocalelor, impreuna cu cate o lista de cuvinte
         */
        private Dictionary<String, ListWords> vowels = new Dictionary<String, ListWords>();

        /**
         * Metoda AddVowel
         * ---------------
         * Adauga o vocala, impreuna cu datele despre ea
         */
        public void AddVowel(Tuple<String, Int32, String, Int32> parameters)
        {
            // blochez obiectul locked
            lock (locked)
            {
                // vocala nu se gaseste in lista de vocale?
                if (!vowels.ContainsKey(parameters.Item1))
                {
                    // adaug vocala in lista
                    vowels[parameters.Item1] = new ListWords();
                }
                // adaug cuvantul in cadrul listei de cuvinte a vocalei
                vowels[parameters.Item1].AddWord(new Tuple<Int32, String, Int32>(parameters.Item2, parameters.Item3, parameters.Item4));
            }
        }

        /**
         * Metoda GetVowels
         * ----------------
         * Preia toate vocalele, impreuna cu datele despre fiecare dintre ele
         */
        public Dictionary<String, List<Tuple<Int32, String, Int32>>> GetVowels()
        {
            // creez o copie a raspunsului
            var answer = new Dictionary<String, List<Tuple<int, string, int>>>();
            // blochez obiectul locked
            lock (locked)
            {
                // parcurg vocalele din lista
                foreach (var vowel in vowels)
                {
                    // le adaug la copie
                    answer[vowel.Key] = ((ListWords)vowel.Value).GetWords();
                }
            }
            // intorc copia
            return answer;
        }

        /**
         * Metoda GetVowel
         * ---------------
         * Preia o vocala, impreuna cu datele despre ea
         */
        public List<Tuple<Int32, String, Int32>> getVowel(String c)
        {
            // creez o copie a raspunsului
            var answer = new List<Tuple<int, string, int>>();
            // blochez obiectul locked
            lock (this)
            {
                // vocala se gaseste in lista de vocale?
                if (vowels.ContainsKey(c))
                {
                    // adaug vocala la raspuns
                    answer = vowels[c].GetWords();
                }
            }
            // intorc raspunsul
            return answer;
        }
    }
}
