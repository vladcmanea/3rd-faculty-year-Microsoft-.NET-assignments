﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace L8F.MyData
{
    /**
     * Clasa ListWords
     * ----------------
     * Retine si lucreaza cu o lista de cuvinte
     */
    class ListWords
    {
        /**
         * Obiectul locked
         * ---------------
         * Un obiect blocabil pentru thread-safety
         */
        private readonly Object locked = new Object();

        /**
         * Dictionarul de cuvinte
         * ------------------
         * Permite stocarea cuvintelor
         */
        private List<Tuple<Int32, String, Int32>> words = new List<Tuple<int, string, int>>();
        
        /**
         * Metoda AddWord
         * --------------
         * Adauga un cuvant
         */
        public void AddWord(Tuple<Int32, String, Int32> parameters)
        {
            // blochez obiectul locked
            lock (locked)
            {
                // adaug cuvantul in lista de cuvinte
                words.Add(parameters);
            }
        }

        /**
         * Metoda GetWords
         * ---------------
         * Preia toate cuvintele
         */
        public List<Tuple<Int32, String, Int32>> GetWords()
        {
            // creez o copie a raspunsului
            List<Tuple<Int32, String, Int32>> answer = new List<Tuple<int, string, int>>();
            // blochez obiectul locked
            lock (locked)
            {
                // parcurg cuvintele din lista de cuvinte
                foreach (var word in words)
                {
                    // adaug cuvantul la lista de cuvinte
                    answer.Add(word);
                }
            }
            // intorc raspunsul
            return answer;
        }
    }
}
