﻿namespace L8F
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.VowelsTree = new System.Windows.Forms.TreeView();
            this.VowelsList = new System.Windows.Forms.ListBox();
            this.WordsList = new System.Windows.Forms.ListBox();
            this.StatisticsBox = new System.Windows.Forms.TextBox();
            this.FileContents = new System.Windows.Forms.RichTextBox();
            this.FileWorker = new System.ComponentModel.BackgroundWorker();
            this.FileDialog = new System.Windows.Forms.OpenFileDialog();
            this.SuspendLayout();
            // 
            // VowelsTree
            // 
            this.VowelsTree.Location = new System.Drawing.Point(13, 13);
            this.VowelsTree.Name = "VowelsTree";
            this.VowelsTree.Size = new System.Drawing.Size(121, 468);
            this.VowelsTree.TabIndex = 0;
            // 
            // VowelsList
            // 
            this.VowelsList.FormattingEnabled = true;
            this.VowelsList.Location = new System.Drawing.Point(141, 13);
            this.VowelsList.Name = "VowelsList";
            this.VowelsList.Size = new System.Drawing.Size(120, 95);
            this.VowelsList.TabIndex = 1;
            this.VowelsList.SelectedIndexChanged += new System.EventHandler(this.VowelsList_SelectedIndexChanged);
            // 
            // WordsList
            // 
            this.WordsList.FormattingEnabled = true;
            this.WordsList.Location = new System.Drawing.Point(268, 13);
            this.WordsList.Name = "WordsList";
            this.WordsList.Size = new System.Drawing.Size(660, 95);
            this.WordsList.TabIndex = 2;
            this.WordsList.SelectedIndexChanged += new System.EventHandler(this.WordsList_SelectedIndexChanged);
            // 
            // StatisticsBox
            // 
            this.StatisticsBox.Location = new System.Drawing.Point(12, 487);
            this.StatisticsBox.Name = "StatisticsBox";
            this.StatisticsBox.Size = new System.Drawing.Size(467, 20);
            this.StatisticsBox.TabIndex = 3;
            // 
            // FileContents
            // 
            this.FileContents.AcceptsTab = true;
            this.FileContents.AutoWordSelection = true;
            this.FileContents.HideSelection = false;
            this.FileContents.Location = new System.Drawing.Point(141, 115);
            this.FileContents.Name = "FileContents";
            this.FileContents.ShowSelectionMargin = true;
            this.FileContents.Size = new System.Drawing.Size(787, 366);
            this.FileContents.TabIndex = 4;
            this.FileContents.Text = "";
            this.FileContents.WordWrap = false;
            // 
            // FileWorker
            // 
            this.FileWorker.WorkerReportsProgress = true;
            this.FileWorker.DoWork += new System.ComponentModel.DoWorkEventHandler(this.FileReadWorker_DoWork);
            this.FileWorker.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this.FileReadWorker_ProgressChanged);
            this.FileWorker.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.FileReadWorker_RunWorkerCompleted);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(940, 519);
            this.Controls.Add(this.FileContents);
            this.Controls.Add(this.StatisticsBox);
            this.Controls.Add(this.WordsList);
            this.Controls.Add(this.VowelsList);
            this.Controls.Add(this.VowelsTree);
            this.Name = "Form1";
            this.Text = "Vowels";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.ComponentModel.BackgroundWorker FileWorker;
        private System.Windows.Forms.OpenFileDialog FileDialog;
        public System.Windows.Forms.TreeView VowelsTree;
        public System.Windows.Forms.ListBox VowelsList;
        public System.Windows.Forms.ListBox WordsList;
        public System.Windows.Forms.TextBox StatisticsBox;
        public System.Windows.Forms.RichTextBox FileContents;
    }
}

