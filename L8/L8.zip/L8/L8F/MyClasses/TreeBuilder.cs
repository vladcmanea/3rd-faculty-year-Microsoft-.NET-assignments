﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using L8F.MyInterfaces;
using System.Threading;
using System.Windows.Forms;
using L8F.MyData;

namespace L8F.MyClasses
{
    /**
     * Clasa TreeBuilder
     * ----------------------
     * Clasa implementeaza ThreadClient.
     * ----------------------------
     * Are ca scop actualizarea in TreeView cu vocale si cuvinte.
     */
    class TreeBuilder : ThreadClient
    {
        /**
         * Obiectul updated
         * ----------------
         * Este obiectul actualizat din exterior, citibil de thread.
         * ---------------------------------------------------------
         * Este implementat thread-safe.
         */
        protected Queue<Tuple<String, String>> updated = new Queue<Tuple<String, String>>();

        /**
         * Delegatul callback
         * ------------------
         * Este delegatul utilizat pentru invocarea elementului de interfata
         * daca este ocupat.
         */
        protected delegate void SetCallback();

        /**
         * Obiectul mutex
         * --------------
         * Este utilizat pentru a sincroniza threadurile.
         */
        protected Mutex mutex = new Mutex();

        /**
         * Metoda UpdateGUI
         * ----------------
         * Daca GUI este ocupat, se reapeleaza in viitor.
         * ----------------------------------------------
         * Noua vocala si cuvantul ei au fost trimise in Updated.
         * Ea va fi citita si adaugata in modelul arborelui.
         */
        public void UpdateGUI()
        {
            // TreeViewul este ocupat?
            if (Program.form.VowelsTree.InvokeRequired)
            {
                // seteaza un callback cu aceeasi metoda
                SetCallback callback = new SetCallback(UpdateGUI);
                // invoca respectivul callback
                Program.form.Invoke(callback);
            }
            else
            {
                // se creeaza o copie locala a Updatedului
                var copy = Updated as List<Tuple<String, String>>;
                // respectiva copie a fost intr-adevar un update corect?
                if (copy != null)
                {
                    // iterez vocalele
                    foreach (Tuple<String, String> vowel in copy)
                    {
                        // variabila ok va spune daca vocala este in arbore
                        Boolean ok = false;
                        // se cauta prin vocalele din arbore
                        foreach (TreeNode node in Program.form.VowelsTree.Nodes)
                        {
                            // daca vocala primita se gaseste in arbore
                            if (node.Text == vowel.Item1)
                            {
                                // doar adaug cuvantul
                                node.Nodes.Add(vowel.Item2);
                                // specific ca am gasit vocala
                                ok = true;
                                // termin parcurgerea, altfel inutila
                                break;
                            }
                        }
                        // vocala nu se gaseste?
                        if (!ok)
                        {
                            // creez un nod de arbore cu vocala
                            TreeNode node = new TreeNode(vowel.Item1);
                            // adaug cuvantul ca fiu al nodului
                            node.Nodes.Add(vowel.Item2);
                            // adaug nodul la arborele model din TreeView
                            Program.form.VowelsTree.Nodes.Add(node);
                        }
                    }
                }
            }
        }

        /**
         * Obiectul updated
         * ----------------
         * Este implementat thread safe.
         */
        public Object Updated
        {
            // getter
            get
            {
                // o copie a obiectului updated
                List<Tuple<String, String>> answer = new List<Tuple<String, String>>();
                // asteapta eliberarea mutexului
                mutex.WaitOne();
                // coada este nevida?
                if (updated.Count > 0)
                {
                    // setez raspunsul
                    answer = updated.ToList();
                    // clear updated
                    updated.Clear();
                }
                // elibereaza mutexul
                mutex.ReleaseMutex();
                // intorc copia
                return answer;
            }

            // setter
            set
            {
                // asteapta eliberarea mutexului
                mutex.WaitOne();
                // is value null?
                if (value == null)
                {
                    // clear updated
                    updated.Clear();
                }
                else
                {
                    // valoarea e valida?
                    if (value is Tuple<String, String>)
                    {
                        // adaug in coada
                        updated.Enqueue(value as Tuple<String, String>);
                    }
                }
                // eliberez mutexul
                mutex.ReleaseMutex();
            }
        }

        /**
         * Metoda Run
         * ----------
         * Metoda se comporta similar 
         * pentru toate threadurile conform cerintei.
         */
        public void Run()
        {
            try
            {
                // rulez la infinit
                while (true)
                {
                    // Thread.Sleep(100);
                    // daca s-a actualizat updated (o citire thread-safe)
                    if (Exists)
                    {
                        // apelez metoda de update a interfetei grafice
                        UpdateGUI();
                    }
                }
            }
            catch (Exception exception)
            {
                // nu e nimic de implementat
                exception = null;
            }
        }


        /**
         * Obiectul exists
         * ---------------
         * Este raspunsul daca exista elemente in update
         */
        public bool Exists
        {
            // getter
            get
            {
                // creeaza o copie a raspunsului
                bool answer;
                // asteapta eliberarea mutexului
                mutex.WaitOne();
                // seteaza copia dupa raspuns
                answer = updated.Count > 0;
                // eliberez mutexul
                mutex.ReleaseMutex();
                // returnez raspunsul
                return answer;
            }
        }
    }
}
