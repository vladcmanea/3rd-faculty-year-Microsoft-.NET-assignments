﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace L8F.MyClasses
{
    /**
     * Clasa Extensions
     * ----------------
     * Clasa de extensii pentru tipurile de date
     */
    public static class Extensions
    {
        /**
         * Metoda isVowel
         * --------------
         * Utilizata in clasa String pentru a raspunde
         * daca respectivul sir este o vocala.
         */
        public static Boolean isVowel(this String vowel)
        {
            // returneaza raspunsul
            return vowel == "a" || vowel == "e" || vowel == "i" 
                || vowel == "o" || vowel == "u"
                || vowel == "A" || vowel == "E" || vowel == "I" 
                || vowel == "O" || vowel == "U";
        }
    }
}
