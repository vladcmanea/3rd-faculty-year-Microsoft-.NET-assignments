﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using L8F.MyInterfaces;
using System.Threading;
using L8F.MyData;

namespace L8F.MyClasses
{
    /**
     * Clasa HighlightBuilder
     * ----------------------
     * Clasa implementeaza ThreadClient.
     * ----------------------------
     * Are ca scop sublinierea in RichText a unui cuvant.
     */
    class HighlightBuilder : ThreadClient
    {
        /**
         * Obiectul updated
         * ----------------
         * Este obiectul actualizat din exterior, citibil de thread.
         * ---------------------------------------------------------
         * Este implementat thread-safe.
         */
        protected Queue<String> updated = new Queue<String>();

        /**
         * Delegatul callback
         * ------------------
         * Este delegatul utilizat pentru invocarea elementului de interfata
         * daca este ocupat.
         */
        protected delegate void SetCallback();

        /**
         * Obiectul mutex
         * --------------
         * Este utilizat pentru a sincroniza threadurile.
         */
        protected Mutex mutex = new Mutex();

        /**
         * Metoda UpdateGUI
         * ----------------
         * Daca GUI este ocupat, se reapeleaza in viitor.
         * ----------------------------------------------
         * Are ca scop sublinierea in RichText a unui cuvant dat.
         * Cuvantul a fost deja pus in Updated si va fi citit de acolo.
         */
        public void UpdateGUI()
        {
            // RichTextul este ocupat?
            if (Program.form.FileContents.InvokeRequired)
            {
                // seteaza un callback cu aceeasi metoda
                SetCallback callback = new SetCallback(UpdateGUI);
                // invoca respectivul callback
                Program.form.Invoke(callback);
            }
            else
            {
                // se creeaza o copie locala a Updatedului
                var copy = Updated as List<String>;
                // respectiva copie a fost intr-adevar un update corect?
                if (copy != null)
                {
                    // iterez vocalele
                    foreach (String row in copy)
                    {
                        // adaug randul la RichText
                        Program.form.FileContents.Text += row + " \n ";
                    }
                }
            }
        }

        /**
         * Obiectul updated
         * ----------------
         * Este implementat thread safe.
         */
        public Object Updated
        {
            // getter
            get
            {
                // o copie a obiectului updated
                List<String> answer = new List<String>();
                // asteapta eliberarea mutexului
                mutex.WaitOne();
                // coada este nevida?
                if (updated.Count > 0)
                {
                    // setez raspunsul
                    answer = updated.ToList();
                    // clear updated
                    updated.Clear();
                }
                // elibereaza mutexul
                mutex.ReleaseMutex();
                // intorc copia
                return answer;
            }

            // setter
            set
            {
                // asteapta eliberarea mutexului
                mutex.WaitOne();
                // is value null?
                if (value == null)
                {
                    // clear updated
                    updated.Clear();
                }
                else
                {
                    // valoarea e valida?
                    if (value is String)
                    {
                        // adaug in coada
                        updated.Enqueue(value as String);
                    }
                }
                // eliberez mutexul
                mutex.ReleaseMutex();
            }
        }

        /**
         * Metoda Run
         * ----------
         * Metoda se comporta similar 
         * pentru toate threadurile conform cerintei.
         */
        public void Run()
        {
            try
            {
                // rulez la infinit
                while (true)
                {
                    // Thread.Sleep(100);
                    // daca s-a actualizat updated (o citire thread-safe)
                    if (Exists)
                    {
                        // apelez metoda de update a interfetei grafice
                        UpdateGUI();
                    }
                }
            }
            catch (Exception exception)
            {
                // nu e nimic de implementat
                exception = null;
            }
        }

        /**
         * Obiectul exists
         * ---------------
         * Este raspunsul daca exista elemente in update
         */
        public bool Exists
        {
            // getter
            get
            {
                // creeaza o copie a raspunsului
                bool answer;
                // asteapta eliberarea mutexului
                mutex.WaitOne();
                // seteaza copia dupa raspuns
                answer = updated.Count > 0;
                // eliberez mutexul
                mutex.ReleaseMutex();
                // returnez raspunsul
                return answer;
            }
        }
    }
}
