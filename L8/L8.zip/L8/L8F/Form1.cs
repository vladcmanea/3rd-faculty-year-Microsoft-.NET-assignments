﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using L8F.MyClasses;
using System.Threading;
using L8F.MyInterfaces;
using L8F.MyData;

namespace L8F
{
    /**
     * Clasa Form1
     * -----------
     * Clasa principala cu formularul si threadurile
     */
    public partial class Form1 : Form, ThreadClient
    {
        /**
         * Delegatul callback
         * ------------------
         * Este delegatul utilizat pentru invocarea elementului de interfata
         * daca este ocupat.
         */
        protected delegate void SetCallback();

        /**
         * Obiectul updated
         * ----------------
         * Este obiectul actualizat din exterior, citibil de thread.
         * ---------------------------------------------------------
         * Este implementat thread-safe.
         */
        private static Queue<Dictionary<String, Int32>> updated = new Queue<Dictionary<String, Int32>>();

        DialogResult result;

        // clientii de threaduri
        ThreadClient vowelsBuilder = null;
        ThreadClient wordsBuilder = null;
        ThreadClient treeBuilder = null;
        ThreadClient highlightBuilder = null;

        // threadurile asociate clientilor
        Thread threadVowelsBuilder = null;
        Thread threadWordsBuilder = null;
        Thread threadTreeBuilder = null;
        Thread threadHighlightBuilder = null;

        // lista de vocale utilizata pentru
        private ListVowels vowels = new ListVowels();
        // dictionarul de statistici pentru fiecare vocala
        private Dictionary<String, Int32> stats = new Dictionary<String, Int32>();
        // delimitatorii intre cuvinte
        Char[] delimiters = new Char[] { ' ', ',' };

        /**
         * Metoda Form1
         * ------------
         * Initializeaza interactiunea si datele membre.
         */
        public Form1()
        {
            InitializeComponent();
            
            // creez un dialog de selectare a fisierului de intrare
            result = FileDialog.ShowDialog();

            // try again
            while (result != DialogResult.OK)
            {
                // creez un dialog de selectare a fisierului de intrare
                result = FileDialog.ShowDialog();
            }

            // creez clientii
            vowelsBuilder = new VowelsBuilder();
            wordsBuilder = new WordsBuilder();
            treeBuilder = new TreeBuilder();
            highlightBuilder = new HighlightBuilder();

            // creez threadurile
            threadVowelsBuilder = new Thread(new ThreadStart(vowelsBuilder.Run));
            threadWordsBuilder = new Thread(new ThreadStart(wordsBuilder.Run));
            threadTreeBuilder = new Thread(new ThreadStart(treeBuilder.Run));
            threadHighlightBuilder = new Thread(new ThreadStart(highlightBuilder.Run));

            // pornesc threadurile
            FileWorker.RunWorkerAsync(FileDialog.FileName);
            threadVowelsBuilder.Start();
            threadWordsBuilder.Start();
            threadTreeBuilder.Start();
            threadHighlightBuilder.Start();
        }

        /**
         * Metoda FileReadWorker_DoWork
         * ----------------------------
         * Se ocupa cu citirea fisierului de intrare
         */
        private void FileReadWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            String argument = e.Argument as String;
            String line;
            // utilizez fisierul de intrare
            using (StreamReader fin = new StreamReader(argument))
            {
                // citesc linie cu linie fisierul de intrare
                for (Int32 index = 0; (line = fin.ReadLine()) != null; ++index)
                {
                    // extrag cuvintele folosind separatorii
                    String[] words = line.Split(delimiters);
                    // pentru fiecare cuvant extras
                    for (Int32 jndex = 0; jndex < words.Length; ++jndex)
                    {
                        // pentru fiecare litera din cuvant
                        for (Int32 kndex = 0; kndex < words[jndex].Length; ++kndex)
                        {
                            // daca litera este vocala
                            if (words[jndex][kndex].ToString().isVowel())
                            {
                                // daca statistica are deja vocala
                                if (stats.ContainsKey(words[jndex][kndex].ToString()))
                                {
                                    // adaug un cuvant la statistica vocalei
                                    ++stats[words[jndex][kndex].ToString()];
                                }
                                else
                                {
                                    // creez statistica vocalei cu fix un cuvant
                                    stats[words[jndex][kndex].ToString()] = 1;
                                }

                                Thread.Sleep(1000);

                                // raportez progresul pentru a fi actualizata interfata
                                FileWorker.ReportProgress(0, new Tuple
                                    <String, Int32, String, Int32>
                                    (
                                        words[jndex][kndex].ToString(),
                                        index,
                                        words[jndex],
                                        jndex
                                    )
                                );
                            }
                        }
                    }

                    // raportez progresul pentru a fi actualizata interfata
                    FileWorker.ReportProgress(0, line);
                }
            }
        }

        /**
         * Metoda FileReadWorker_ProgressChanged
         * -------------------------------------
         * Se apeleaza automat din BackgroundWorker la raportarea progresului
         */
        private void FileReadWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            // este actualizare de vocala?
            if (e.UserState is Tuple<String, Int32, String, Int32>)
            {
                // actualizez in toate threadurile, mai putin cel highlight
                Tuple<String, Int32, String, Int32> state = e.UserState as Tuple<String, Int32, String, Int32>;
                Tuple<String, String> vowelWord = new Tuple<String, String>(state.Item1, state.Item3);
                vowels.AddVowel(state);
                vowelsBuilder.Updated = state.Item1;
                treeBuilder.Updated = vowelWord;
                Updated = stats;
            }
            // este actualizare de rand?
            else if (e.UserState is String)
            {
                // actualizez in threadul highlight
                highlightBuilder.Updated = e.UserState.ToString();
            }
        }

        /**
         * Metoda FileReadWorker_RunWorkerCompleted
         * ----------------------------------------
         * Se apeleaza automat din BackgroundWorker la terminarea lucrului
         */
        private void FileReadWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            // nu e necesar cod, am implementat doar pt a fi complet
        }

        /**
         * Metoda Form1_FormClosing
         * ------------------------
         * Se apeleaza automat cand se inchide formularul
         */
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            // clean
            this.Clean();
        }

        /**
         * Metoda VowelsList_SelectedIndexChanged
         * --------------------------------------
         * Se apeleaza automat cand se selecteaza o vocala din ListBoxul de vocale
         */
        private void VowelsList_SelectedIndexChanged(object sender, EventArgs e)
        {
            // setez o vocala noua si datele despre ea in threadul pentru ListBoxul de cuvinte
            wordsBuilder.Updated = vowels.getVowel(((ListBox)sender).SelectedItem.ToString());
        }

        /**
         * Metoda WordsList_SelectedIndexChanged
         * -------------------------------------
         * Se apeleaza automat cand se selecteaza un cuvant din ListBoxul de cuvinte
         */
        private void WordsList_SelectedIndexChanged(object sender, EventArgs e)
        {
            // preiau textul din item
            String item = ((ListBox)sender).SelectedItem.ToString();
            // preiau tokenii din item
            String[] tokens = item.Split(new char[] { '[', ']', '|', ' ' });
            // preiau numarul randului
            Int32 maxRow = Int32.Parse(tokens[1]);
            // preiau numarul cuvantului
            Int32 maxWord = Int32.Parse(tokens[4]);
            // preiau cuvintele din RichText
            String[] words = FileContents.Text.Split(delimiters);
            // declar variabile pentru rand, cuvant
            Int32 row, word, dim, count = -1;
            // iterez cuvintele
            for (row = word = dim = 0; word < words.Length; 
                dim += words[word++].Length + 1)
            {
                // cuvantul este un sfarsit de linie?
                if (words[word] == "\n")
                {
                    // am trecut pe un rand nou
                    ++row;
                    // pe respectivul rand nu sunt cuvinte
                    count = -1;
                }
                else
                {
                    // am mai gasit un cuvant pe acel rand
                    ++count;
                }
                // sunt pe cuvantul cautat?
                if (row == maxRow && count == maxWord)
                {
                    // unselect
                    FileContents.Select(dim, words[word].Length);
                    // termin parcurgerea
                    break;
                }
            }
        }

        private void Clean()
        {
            // inchid threadul pentru vocale
            if (threadVowelsBuilder != null)
            {
                threadVowelsBuilder.Abort();
            }
            // inchid threadul pentru vocale
            if (threadWordsBuilder != null)
            {
                threadWordsBuilder.Abort();
            }
            // inchid threadul pentru cuvinte
            if (threadTreeBuilder != null)
            {
                threadTreeBuilder.Abort();
            }
            // inchid threadul pentru highlight
            if (threadHighlightBuilder != null)
            {
                threadHighlightBuilder.Abort();
            }
            // inchid formularul
            Application.Exit();
        }

        /**
          * Metoda UpdateGUI
          * ----------------
          * Daca GUI este ocupat, se reapeleaza in viitor.
          * ----------------------------------------------
          * Are ca scop crearea de statistici in TextBox.
          * Datele au fost deja puse in Updated si vor fi citite de acolo.
          */
        public void UpdateGUI()
        {
            // TextBoxul este ocupat?
            if (Program.form.StatisticsBox.InvokeRequired)
            {
                // seteaza un callback cu aceeasi metoda
                SetCallback callback = new SetCallback(UpdateGUI);
                // invoca respectivul callback
                Invoke(callback);
            }
            else
            {
                // se creeaza o copie locala a Updatedului
                var copy = Updated as List<Dictionary<String, Int32>>;
                // respectiva copie a fost intr-adevar un update corect?
                if (copy != null)
                {
                    // iterez elementele
                    foreach (Dictionary<String, Int32> index in copy)
                    {
                        // actualizez TextBoxul
                        Program.form.StatisticsBox.Text = "";
                        // iterez vocalele
                        foreach (var vowel in index)
                        {
                            // adaug vocala in TextBox
                            StatisticsBox.Text += vowel.Key + " " + vowel.Value + "; ";
                        }
                    }
                }
            }
        }

        /**
         * Obiectul updated
         * ----------------
         * Este implementat thread safe.
         */
        public Object Updated
        {
            // getter
            get
            {
                // creez o copie
                List<Dictionary<String, Int32>> answer = new List<Dictionary<String, Int32>>();
                // blochez clasa
                lock (typeof(Program))
                {
                    // coada este nevida?
                    if (updated.Count > 0)
                    {
                        // setez raspunsul
                        answer = updated.ToList();
                        // sterg elementele
                        updated.Clear();
                    }
                }
                // intorc raspunsul
                return answer;
            }

            // setter
            set
            {
                // este valoarea de tipul dat?
                if (value is Dictionary<String, Int32>)
                {
                    // folosesc lock pentru thread safe
                    lock (typeof(Program))
                    {
                        // setez updated
                        updated.Enqueue(value as Dictionary<String, Int32>);
                    }

                    // actualizez interfata grafica
                    UpdateGUI();
                }
            }
        }

        /**
         * Obiectul exists
         * ---------------
         * Este raspunsul daca exista elemente in update
         */
        public bool Exists
        {
            // getter
            get
            {
                // creeaza o copie a raspunsului
                bool answer;
                // blochez clasa
                lock (typeof(Program))
                {
                    // seteaza copia dupa raspuns
                    answer = updated.Count > 0;
                }
                // returnez raspunsul
                return answer;
            }
        }

        /**
         * Metoda Run
         * ----------
         * Metoda se comporta similar 
         * pentru toate threadurile conform cerintei.
         */
        public void Run()
        {
            try
            {
                // rulez la infinit
                while (true)
                {
                    // daca s-a actualizat updated (o citire thread-safe)
                    if (Exists)
                    {
                        // apelez metoda de update a interfetei grafice
                        UpdateGUI();
                    }
                }
            }
            catch (Exception exception)
            {
                // nu e nimic de implementat
                exception = null;
            }
        }
    }
}
