﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.IO;

namespace L7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        /** define event happening when button is clicked. */
        private void countButton_Click(object sender, EventArgs e)
        {
            /** is background worker free to run? */
            if (backgroundWorker.IsBusy == false)
            {
                /** show dialog to choose file to be read. */
                DialogResult result = fileDialog.ShowDialog();

                /** has dialog been accepted by user? */
                if (result == DialogResult.OK)
                {
                    /** start background worker. */
                    backgroundWorker.RunWorkerAsync(fileDialog.FileName);
                }
            }
        }

        /** define event happening when worker is started. */
        private void backgroundWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            /** some pretty useful data. */
            String argument = e.Argument as String;
            String line;
            Int32 counts = 0;
            Char[] split = new Char[] { ' ' };

            /** initialize progress bar. */
            backgroundWorker.ReportProgress(0);

            /** initialize words on lines. */
            wordsCount.Items.Clear();

            /** initialize total words. */
            resultBox.Text = "";

            /** open, read and close the file chosen by user. */
            using (StreamReader fin = new StreamReader(argument))
            {
                /** read lines in file. */
                for (Int32 index = 1; (line = fin.ReadLine()) != null; ++index)
                {
                    /** find length of line. */
                    Int32 lcount = line.Split(split).Length;
                    
                    /** report progress on bar. */
                    backgroundWorker.ReportProgress((Int32)(index * 100 / (index + 100)), 
                        new Tuple<Int32, Int32>(index, lcount));

                    /** add line count to counts. */
                    counts += lcount;

                    Thread.Sleep(100);
                }
            }

            /** report progress on bar. */
            backgroundWorker.ReportProgress(100);

            /** send result to completed. */
            e.Result = counts;
        }

        /** define event happening when progress is changed. */
        private void backgroundWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            /** set the value in the progress bar. */
            progressBar.Value = e.ProgressPercentage;

            if (e.UserState != null)
            {
                /** get update tuple. */
                Tuple<Int32, Int32> tuple = e.UserState as Tuple<Int32, Int32>;

                /** set the value in words count. */
                wordsCount.Items.Add("linia " + tuple.Item1.ToString()
                    + " are " + tuple.Item2.ToString() + " cuvint(e)");
            }
        }

        /** define event happening when worker is finished. */
        private void backgroundWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            /** put the total sum of words in gui. */
            resultBox.Text = "un total de " + e.Result.ToString() + " cuvinte";
        }
    }
}
