﻿/**
 * nume si prenume: Manea Vlad
 * email: vlad.manea@info.uaic.ro
 * an: III
 * grupa: 6
 * data realizarii: 31 octombrie 2010
 * data laboratorului: 4 noiembrie 2010
 */

using System;
using System.Collections.Generic;
using System.Linq;
using MVC.Model.Interfaces;
using MVC.Model.BaseClasses;

/**
 * Spatiul de nume pentru modelele concrete necesare laboratorului 5.
 */
namespace MVC.Model.ConcreteClasses
{
    /**
     * Clasa bicicleta defineste date si delegati 
     * pentru produsele de tip tricou.
     */
    public class Bicycle : Product
    {
        /**
         * Definesc regiunea constructorilor.
         */
        #region "Constructors"

        /**
         * Constructor cu date primite din clasele derivate din racoritoare.
         * In el se creeaza diferiti delegati pentru set/get zahar, garantie 
         * etc.
         */
        public Bicycle(String _name, Int32 _price, Int32 _stock,
            String _prod, Int32 _dimension, Double _weight, Int32 _speeds,
            Dictionary<String, Tuple<Object, DModelGetAction,
            DModelSetAction>> _propertiesAndActions) :
            base(_name, _price, _stock, _prod, _propertiesAndActions.Concat(new
                Dictionary<String, Tuple<Object, DModelGetAction,
                 DModelSetAction>>() {
                    {"dimension", new Tuple<Object, DModelGetAction, 
                        DModelSetAction>(_dimension, 
                        GetDimension, SetDimension)},
                    {"weight", new Tuple<Object, DModelGetAction, 
                        DModelSetAction>(_weight, 
                        GetWeight, SetWeight)},
                    {"speeds", new Tuple<Object, DModelGetAction, 
                        DModelSetAction>(_speeds, 
                        null, SetSpeeds)}
            }).ToDictionary(e => e.Key, e => e.Value))
        {
            // nu scriu nimic...
        }

        #endregion

        /**
         * Datele uzuale pentru biciclete sunt:
         * - dimensiune
         * - greutate
         * - numarul de viteze
         */
        #region "Data"

        // creez un delegat pentru setarea dimensiunii (in inch).
        private static DModelSetAction SetDimension =
            delegate(Object _dimension, IModel _model)
            {
                // cantitatea este in parametrii normali?
                if (_dimension is Int32
                    && 10 <= Int32.Parse(_dimension.ToString())
                    && Int32.Parse(_dimension.ToString()) <= 30)
                {
                    // setez dimensiunea.
                    _model["dimension", true] = _dimension;
                }
                else if (_dimension is Int32
                    && 10 > Int32.Parse(_dimension.ToString()))
                {
                    // setez dimensiunea implicita.
                    _model["dimension", true] = 10;
                }
                else if (_dimension is Int32
                    && Int32.Parse(_dimension.ToString()) > 30)
                {
                    // setez dimensiunea implicita.
                    _model["dimension", true] = 30;
                }
                else
                {
                    // setez dimensiunea implicita.
                    _model["dimension", true] = 20;
                }
            };

        // creez un delegat pentru preluarea dimensiunii (in inch).
        private static DModelGetAction GetDimension =
            delegate(IModel _model)
            {
                // intorc dimensiunea, la care adaug unitatea de masura
                return _model["dimension", true];
            };

        // creez un delegat pentru setarea greutatii (in Kg).
        private static DModelSetAction SetWeight =
            delegate(Object _weight, IModel _model)
            {
                // cantitatea este in parametrii normali?
                if (_weight is Double
                    && 5.0 <= Double.Parse(_weight.ToString()) 
                    && Double.Parse(_weight.ToString()) <= 15.0)
                {
                    // setez greutatea.
                    _model["weight", true] = _weight;
                }
                else if (_weight is Double
                    && 5.0 > Double.Parse(_weight.ToString()))
                {
                    // setez greutatea implicita.
                    _model["weight", true] = 5.0;
                }
                else if (_weight is Double
                    && Double.Parse(_weight.ToString()) > 15.0)
                {
                    // setez greutatea implicita.
                    _model["weight", true] = 15.0;
                }
                else
                {
                    // setez greutatea implicita.
                    _model["weight", true] = 10.0;
                }
            };

        // creez un delegat pentru preluarea greutatii (in Kg).
        private static DModelGetAction GetWeight =
            delegate(IModel _model)
            {
                // intorc greutatea, la care adaug unitatea de masura
                return _model["weight", true];
            };

        // creez un delegat pentru setarea numarului de viteze.
        private static DModelSetAction SetSpeeds =
            delegate(Object _speeds, IModel _model)
            {
                if (_speeds is Int32
                    && 1 <= Int32.Parse(_speeds.ToString())
                    && Int32.Parse(_speeds.ToString()) <= 24)
                {
                    // setez numarul de viteze.
                    _model["speeds", true] = _speeds;
                }
                else if (_speeds is Int32
                    && 1 > Int32.Parse(_speeds.ToString()))
                {
                    // setez implicit numarul de viteze.
                    _model["speeds", true] = 1;
                }
                else if (_speeds is Int32
                    && Int32.Parse(_speeds.ToString()) > 24)
                {
                    // setez implicit numarul de viteze.
                    _model["speeds", true] = 24;
                }
                else 
                {
                    // setez implicit numarul de viteze.
                    _model["speeds", true] = 1;
                }
            };

        #endregion
    }
}
