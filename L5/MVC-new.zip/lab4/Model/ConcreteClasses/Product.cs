﻿/**
 * nume si prenume: Manea Vlad
 * email: vlad.manea@info.uaic.ro
 * an: III
 * grupa: 6
 * data realizarii: 31 octombrie 2010
 * data laboratorului: 4 noiembrie 2010
 */

using System;
using System.Collections.Generic;
using System.Linq;
using MVC.Model.BaseClasses;
using MVC.Model.Interfaces;

/**
 * Spatiul de nume pentru modelele concrete necesare laboratorului 5.
 */
namespace MVC.Model.ConcreteClasses
{
    /**
     * Clasa produs defineste date si delegati pentru toate produsele.
     */
    public class Product: BModel
    {
        /**
         * Definesc regiunea constructorilor.
         */
        #region "Constructors"

        /**
         * Constructor cu date primite din clasele derivate din Product.
         * In el se creeaza diferiti delegati pentru set/get nume, pret etc.
         */
        public Product(String _name, Int32 _price, Int32 _stock,
            String _prod, Dictionary<String, Tuple<Object,
            DModelGetAction, DModelSetAction>>
            _propertiesAndActions) :
            base(_propertiesAndActions.Concat(new Dictionary<String,
                 Tuple<Object, DModelGetAction,
                 DModelSetAction>>() {
                    {"name", new Tuple<Object, DModelGetAction, 
                        DModelSetAction>(_name, GetName, SetName)},
                    {"price", new Tuple<Object, DModelGetAction, 
                        DModelSetAction>(_price, null, SetPrice)},
                    {"stock", new Tuple<Object, DModelGetAction, 
                        DModelSetAction>(_stock, null, SetStock)},
                    {"producer", new Tuple<Object, DModelGetAction, 
                        DModelSetAction>(_prod, null, null)}
            }).ToDictionary(e => e.Key, e => e.Value))
        {
            // nu scriu nimic...
        }

        #endregion

        /**
         * Datele uzuale pentru produse sunt:
         * - nume
         * - pret
         * - stoc
         * - producator
         */
        #region "Data"

        // creez un delegat pentru setarea numelui.
        private static DModelSetAction SetName = 
            delegate(Object _name, IModel _model) 
        {
            // este sir de caractere?
            if (_name is String)
            {
                // setez numele
                _model["name", true] = _name;
            }
        };

        // creez un delegat pentru preluarea numelui.
        private static DModelGetAction GetName = 
            delegate(IModel _model)
        {
            // preiau numele
            return _model["name", true];
        };

        // creez un delegat pentru setarea stocului.
        private static DModelSetAction SetStock = 
            delegate(Object _stock, IModel _model)
        {
            // stocul este intreg?
            if (_stock is Int32)
            {
                // am realizat stoc pozitiv?
                if (Int32.Parse(_stock.ToString()) >= 0)
                {
                    // actualizez stocul.
                    _model["stock", true] = Int32.Parse(_stock.ToString());
                }
            }
        };

        // creez un delegat pentru setarea pretului.
        private static DModelSetAction SetPrice = 
            delegate(Object _price, IModel _model)
        {
            // este pretul nou numar intreg?
            if (_price is Int32)
            {
                // am realizat pret pozitiv?
                if (Int32.Parse(_price.ToString()) >= 0)
                {
                    // actualizez stocul.
                    _model["price", true] = Int32.Parse(_price.ToString());
                }
            }
        };
        
        #endregion
    }
}
