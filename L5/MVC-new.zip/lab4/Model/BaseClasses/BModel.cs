﻿/**
 * nume si prenume: Manea Vlad
 * email: vlad.manea@info.uaic.ro
 * an: III
 * grupa: 6
 * data realizarii: 31 octombrie 2010
 * data laboratorului: 4 noiembrie 2010
 */

using System;
using System.Collections.Generic;
using MVC.Model.Interfaces;
using MVC.View.Interfaces;

/**
 * Spatiul de nume pentru clasele de baza necesare laboratorului 5.
 */
namespace MVC.Model.BaseClasses
{
    /**
     * Clasa BModel este utilizata pentru a stabili contractul intre 
     * model si celelalte doua componente: view si control. Am proiectat 
     * modelul sa permita proprietati dinamice. 
     * 
     * Proprietatile "concrete" necesare vor fi implementate in clase 
     * abstracte care implementeaza interfata IModel.
     *
     * Modelul nu isi cunoaste controlul, dar isi cunoaste viewurile care
     * asteapta sa fie notificate.
     */
    public class BModel: IModel
    {
        /**
         * Definesc regiunea constructorilor.
         */
        #region "Constructors"

        /**
         * Definesc constructorul care primeste proprietatile si actiunile.
         */
        public BModel(Dictionary<String, Tuple<Object, DModelGetAction,
            DModelSetAction>> _propertiesAndActions)
        {
            // setez proprietatile & actiunile.
            propertiesAndActions = _propertiesAndActions;
        }

        #endregion

        /**
         * Impun sa se poata 1. accesa si 2. modifica (desigur, public)
         * proprietatile oricarui model prin model[numeproprietate]. Acest
         * lucru este util pentru proprietati dinamice, necunoscute a priori.
         */
        #region "Properties & Actions"

        // retin proprietatile intr-o structura de date de tip dictionar.
        // tuplul contine: <valoare_implicita, delegat_get, delegat_set>
        private Dictionary<String, Tuple<Object, DModelGetAction, 
            DModelSetAction>> propertiesAndActions = new Dictionary<String, 
                Tuple<Object, DModelGetAction, DModelSetAction>>();

        /**
         * * Incapsularea pentru ca modelul sa nu intre in stari inconsistente
         * va fi implementata in clasele concrete pentru fiecare tip de model
         * in parte.
         * 
         * O operatie set este echivalenta cu apelul delegatului de setare.
         * Daca acesta nu exista, se face o setare obisnuita.
         * 
         * O operatie get este echivalenta cu apelul delegatului de preluare.
         * Daca acesta nu exista, se face o preluare obisnuita.
         * 
         * Daca directly este false, se incearca o setare/preluare delegat.
         * Daca directly este true sau nu exista delegat, se face obisnuit.
         */
        public Object this[string _property, bool _directly]
        {
            get
            {
                // numele proprietatii exista in dictionar?
                if (propertiesAndActions.ContainsKey(_property))
                {
                    // delegatul de get exista in dictionar?
                    if (_directly == false && 
                        propertiesAndActions[_property].Item2 != null)
                    {
                        // intorc valoarea asociata numelui proprietatii.
                        return propertiesAndActions[_property].Item2(this);
                    }
                    else
                    {
                        // intorc direct valoarea parametrului.
                        return propertiesAndActions[_property].Item1;
                    }
                }
                else
                {
                    // nu am gasit proprietatea.
                    return "";
                }
            }
            set
            {
                // numele proprietatii exista in dictionar?
                if (propertiesAndActions.ContainsKey(_property))
                {
                    // delegatul de set exista in dictionar?
                    if (_directly == false && 
                        propertiesAndActions[_property].Item3 != null)
                    {
                        // setez valoarea asociata numelui proprietatii.
                        propertiesAndActions[_property].Item3(value, this);
                    }
                    else
                    {
                        // creez un tuplu nou..
                        Tuple<Object, DModelGetAction, DModelSetAction> 
                            auxiliary = new Tuple<Object, DModelGetAction,
                            DModelSetAction>(value, 
                            propertiesAndActions[_property].Item2, 
                            propertiesAndActions[_property].Item3);

                        // il pun la proprietatea respectiva.
                        propertiesAndActions[_property] = auxiliary;
                    }

                    // notific observatorii.
                    NotifyObservers();
                }
            }
        }

        #endregion

        /**
         * Impun modelul de proiectare Observer. Modelul are o lista de
         * elemente ce implementeaza interfata pentru view (IView) care vor
         * fi anuntate dupa ce o proprietate a modelului va fi modificata.
         * Functiile standard sunt cele de adaugare, stergere si notificare.
         */
        #region "Management"

        // retin lista de observatori.
        private HashSet<IView> observers = new HashSet<IView>();

        /**
         * Definesc functia de inregistrare a unui observator de tip IView.
         */
        public void RegisterObserver(IView _view)
        {
            // adaug observatorul in lista de observatori.
            observers.Add(_view);
        }

        /**
         * Definesc functia de eliminare a unui observator de tip IView.
         */
        public void UnregisterObserver(IView _view)
        {
            // sterg observatorul din lista de observatori.
            observers.Remove(_view);
        }

        /**
         * Definesc functia de notificare a tuturor observerilor inregistrati.
         */
        public void NotifyObservers()
        {
            // pentru fiecare observator:
            foreach(IView observer in observers)
            {
                // actualizez observatorul.
                observer.UpdateObserver(this);
            }
        }

        #endregion
    }
}
