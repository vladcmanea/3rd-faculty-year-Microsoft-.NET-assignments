﻿/**
 * nume si prenume: Manea Vlad
 * email: vlad.manea@info.uaic.ro
 * an: III
 * grupa: 6
 * data realizarii: 31 octombrie 2010
 * data laboratorului: 4 noiembrie 2010
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MVC.View.Interfaces;

/**
 * Spatiul de nume pentru interfetele necesare laboratorului 5.
 */
namespace MVC.Model.Interfaces
{
    // declar un delegat pentru actiunea set.
    public delegate void DModelSetAction(Object _parameter, IModel _model);

    // declar un delegat pentru actiunea get.        
    public delegate Object DModelGetAction(IModel _model);

    /**
     * Interfata IModel este utilizata pentru a stabili contractul intre model 
     * si celelalte doua componente: view si control. Am proiectat modelul
     * sa permita proprietati dinamice. 
     * 
     * Proprietatile "concrete" necesare vor 
     * fi implementate in clase abstracte care implementeaza interfata IModel.
     * 
     * Modelul nu isi cunoaste controlul, dar isi cunoaste viewurile care
     * asteapta sa fie notificate.
     */
    public interface IModel
    {
        /**
         * Impun sa se poata 1. accesa si 2. modifica (desigur, public)
         * proprietatile oricarui model prin model[numeproprietate]. Acest
         * lucru este util pentru proprietati dinamice, necunoscute a priori.
         */
        #region "Properties & Actions"

        /**
         * * Incapsularea pentru ca modelul sa nu intre in stari inconsistente
         * va fi implementata in clasele concrete pentru fiecare tip de model
         * in parte.
         */
        Object this[string _property, bool _directly]
        {
            get;
            set;
        }

        #endregion

        /**
         * Impun modelul de proiectare Observer. Modelul are o lista de
         * elemente ce implementeaza interfata pentru view (IView) care vor
         * fi anuntate dupa ce o proprietate a modelului va fi modificata.
         * Functiile standard sunt cele de adaugare, stergere si notificare.
         */
        #region "Management"

        /**
         * Declar functia de inregistrare a unui observator de tip IView.
         */
        void RegisterObserver(IView _view);

        /**
         * Declar functia de eliminare a unui observator de tip IView.
         */
        void UnregisterObserver(IView _view);

        /**
         * Declar functia de notificare a tuturor observerilor inregistrati.
         */
        void NotifyObservers();

        #endregion
    }
}
