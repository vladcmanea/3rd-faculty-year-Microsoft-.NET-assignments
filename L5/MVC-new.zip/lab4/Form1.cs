﻿/**
 * nume si prenume: Manea Vlad
 * email: vlad.manea@info.uaic.ro
 * an: III
 * grupa: 6
 * data realizarii: 31 octombrie 2010
 * data laboratorului: 4 noiembrie 2010
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MVC.Control.Interfaces;
using MVC.View.Interfaces;

namespace MVC
{
    public partial class Form1 : Form
    {
        /**
         * Definesc regiunea de modele, viewuri si controluri.
         */
        #region "Data"

        MVC.Model.ConcreteClasses.Bicycle bicycleItemModel;
        MVC.Model.ConcreteClasses.Refreshment refreshmentItemModel;
        MVC.Model.ConcreteClasses.Tshirt tshirtItemModel;
        MVC.Model.ConcreteClasses.Product bicycleProductModel;
        MVC.Model.ConcreteClasses.Product refreshmentProductModel;
        MVC.Model.ConcreteClasses.Product tshirtProductModel;

        MVC.Control.ConcreteClasses.Bicycle bicycleItemControl;
        MVC.Control.ConcreteClasses.Refreshment refreshmentItemControl;
        MVC.Control.ConcreteClasses.Tshirt tshirtItemControl;
        MVC.Control.ConcreteClasses.Product bicycleProductControl;
        MVC.Control.ConcreteClasses.Product refreshmentProductControl;
        MVC.Control.ConcreteClasses.Product tshirtProductControl;

        #endregion

        /**
         * Definesc regiunea constructorilor.
         */
        #region "Constructors"

        public Form1()
        {
            InitializeComponent();

            // creez modelele
            bicycleItemModel = new MVC.Model.ConcreteClasses.Bicycle("Bicicleta",
                10, 0, "BMX", 10, 10, 4,
                new Dictionary<string, Tuple<object, Model.Interfaces.DModelGetAction,
                Model.Interfaces.DModelSetAction>>());
            tshirtItemModel = new MVC.Model.ConcreteClasses.Tshirt("Tricou",
                10, 0, "Nike", "Red", "Wool", 40,
                new Dictionary<string, Tuple<object, Model.Interfaces.DModelGetAction,
                Model.Interfaces.DModelSetAction>>());
            refreshmentItemModel = new MVC.Model.ConcreteClasses.Refreshment("Suc",
                10, 10, "Coke", 2, new DateTime(2010, 10, 1), 
                new Dictionary<string, Tuple<object, Model.Interfaces.DModelGetAction,
                Model.Interfaces.DModelSetAction>>());
            bicycleProductModel = (MVC.Model.ConcreteClasses.Product)bicycleItemModel;
            tshirtProductModel = (MVC.Model.ConcreteClasses.Product)tshirtItemModel;
            refreshmentProductModel = (MVC.Model.ConcreteClasses.Product)refreshmentItemModel;
            
            // creez controlurile
            bicycleItemControl = new MVC.Control.ConcreteClasses.Bicycle(bicycleItemModel, bicycle1, 
                new Dictionary<string, DControlSetAction>());
            refreshmentItemControl = new MVC.Control.ConcreteClasses.Refreshment(refreshmentItemModel, refreshment1,
                new Dictionary<string, DControlSetAction>());
            tshirtItemControl = new MVC.Control.ConcreteClasses.Tshirt(tshirtItemModel, tshirt1,
                new Dictionary<string, DControlSetAction>());
            bicycleProductControl = new MVC.Control.ConcreteClasses.Product(bicycleProductModel, product1,
                new Dictionary<string, DControlSetAction>());
            refreshmentProductControl = new MVC.Control.ConcreteClasses.Product(refreshmentProductModel, product2,
                new Dictionary<string, DControlSetAction>());
            tshirtProductControl = new MVC.Control.ConcreteClasses.Product(tshirtProductModel, product3,
                new Dictionary<string, DControlSetAction>());

            // configurez viewurile
            bicycle1.Control = bicycleItemControl;
            refreshment1.Control = refreshmentItemControl;
            tshirt1.Control = tshirtItemControl;
            product1.Control = bicycleProductControl;
            product2.Control = refreshmentProductControl;
            product3.Control = tshirtProductControl;
            bicycle1.Model = bicycleItemModel;
            refreshment1.Model = refreshmentItemModel;
            tshirt1.Model = tshirtItemModel;
            product1.Model = bicycleProductModel;
            product2.Model = refreshmentProductModel;
            product3.Model = tshirtProductModel;

            // updatez viewurile
            bicycle1.UpdateObserver(bicycle1.Model);
            refreshment1.UpdateObserver(refreshment1.Model);
            tshirt1.UpdateObserver(tshirt1.Model);
            product1.UpdateObserver(product1.Model);
            product2.UpdateObserver(product2.Model);
            product3.UpdateObserver(product3.Model);
        }

        #endregion

        /**
         * Definesc regiunea evenimentelor.
         */
        #region "Events"

        private void Form1_Load(object sender, EventArgs e)
        {
            listBox1.Items.Add("Bicycle");
            listBox1.Items.Add("Refreshment");
            listBox1.Items.Add("Tshirt");
            this.product1.Hide();
            this.product2.Hide();
            this.product3.Hide();
            this.bicycle1.Hide();
            this.tshirt1.Hide();
            this.refreshment1.Hide();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.product1.Hide();
            this.product2.Hide();
            this.product3.Hide();
            this.bicycle1.Hide();
            this.tshirt1.Hide();
            this.refreshment1.Hide();

            switch ((String)listBox1.SelectedItem)
            {
                case "Bicycle":
                    this.product1.Show();
                    this.bicycle1.Show();
                    break;
                case "Refreshment":
                    this.product2.Show();
                    this.refreshment1.Show();
                    break;
                case "Tshirt":
                    this.product3.Show();
                    this.tshirt1.Show();
                    break;
            }
        }

        #endregion
    }
}
