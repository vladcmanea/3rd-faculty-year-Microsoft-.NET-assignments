﻿/**
 * nume si prenume: Manea Vlad
 * email: vlad.manea@info.uaic.ro
 * an: III
 * grupa: 6
 * data realizarii: 31 octombrie 2010
 * data laboratorului: 4 noiembrie 2010
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MVC.View.Interfaces;
using MVC.Model.Interfaces;

/**
 * Spatiul de nume pentru interfetele necesare laboratorului 5.
 */
namespace MVC.Control.Interfaces
{
    // declar un delegat pentru actiune.
    public delegate void DControlSetAction(Object _parameter,
        IModel _model, IView _view);

    /**
     * Interfata IControl este utilizata pentru a stabili contractul intre 
     * control si celelalte doua componente: view si model. Am proiectat 
     * controlul sa permita transmiterea de proprietati dinamice spre model. 
     * 
     * Controlul isi cunoaste si modelul, si viewul.
     */
    public interface IControl
    {
        /**
         * Impun sa se poata realiza (desigur, public) actiuni asupra 
         * modelului oricarui control prin control[numeactiune]. Acest lucru
         * este util pentru proprietati dinamice, necunoscute a priori.
         */
        #region "Actions"

        /**
         * Cand se apeleaza control[numeactiune] = obiect, controlul va 
         * intelege ca se aplica o actiune si se transmite un obiect 
         * (optional). In aceasta metoda din aceasta clasa abstracta 
         * nu se intampla nimic, deoarece actiunile vor fi definite 
         * in clase concrete.
         */
        Object this[string _action]
        {
            set;
        }

        #endregion

        /**
         * Permit doar schimbarea viewului si modelului pentru control.
         */
        #region "Management"

        /**
         * Permit doar schimbarea viewului in control.
         */
        IView View
        {
            set;
        }

        /**
         * Permit doar schimbarea modelului in control.
         */
        IModel Model
        {
            set;
        }

        #endregion
    }
}
