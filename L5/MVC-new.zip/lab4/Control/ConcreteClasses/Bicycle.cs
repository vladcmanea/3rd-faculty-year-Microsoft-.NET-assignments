﻿/**
 * nume si prenume: Manea Vlad
 * email: vlad.manea@info.uaic.ro
 * an: III
 * grupa: 6
 * data realizarii: 31 octombrie 2010
 * data laboratorului: 4 noiembrie 2010
 */

using System;
using System.Collections.Generic;
using System.Linq;
using MVC.Model.Interfaces;
using MVC.View.Interfaces;
using MVC.Control.Interfaces;

/**
 * Spatiul de nume pentru controlurile concrete necesare laboratorului 5.
 */
namespace MVC.Control.ConcreteClasses
{
    /**
     * Clasa bicicleta defineste actiuni pentru toate bicicletele.
     */
    public class Bicycle : Product
    {
        /**
         * Definesc regiunea constructorilor.
         */
        #region "Constructors"

        /**
         * Definesc constructorul care primeste un model, 
         * un control si delegatele pentru actiuni de la subclase.
         */
        public Bicycle(IModel _model, IView _view,
            Dictionary<String, DControlSetAction> _actions)
            : base(_model,
                _view, _actions.Concat(new
                Dictionary<String, DControlSetAction>() {
                    {"speeds", IncDecSpeeds},
                    {"dimension", IncDecDimension},
                    {"weight", ModWeight}
            }).ToDictionary(e => e.Key, e => e.Value))
        {
            // nu scriu nimic...
        }

        #endregion

        /**
         * Declar constrangerile Business.
         */
        #region "Business"

        /**
         * Definesc un delegat pentru cresterea sau 
         * scaderea cu 1 a numarului de viteze.
         * Actualizez datele pentru tipurile: kids, old sau altul.
         */
        private static DControlSetAction IncDecSpeeds =
            delegate(Object _direction, IModel _model, IView _view)
            {
                // directia este boolean?
                if (_direction is Boolean)
                {
                    // directia este adevarat?
                    if (Boolean.Parse(_direction.ToString()) == true)
                    {
                        // setez numarul de viteze mai mare.
                        _model["speeds", false] = 
                            Int32.Parse(_model["speeds", false].ToString()) 
                            + 1;
                    }
                    else
                    {
                        // setez numarul de viteze mai mic.
                        _model["speeds", false] = 
                            Int32.Parse(_model["speeds", false].ToString()) 
                            - 1;
                    }
                    // testez actiunea pentru view
                    if (Int32.Parse(_model["dimension", false].ToString()) 
                        <= 15 && Double.Parse(_model["weight", false].ToString())
                        <= 7.5 && Int32.Parse(_model["speeds", false].ToString())
                        <= 8)
                    {
                        // consider bicicleta pentru copii.
                        _view["type"] = "kids";
                    }
                    else if (Int32.Parse(_model["dimension", false].ToString()) 
                        >= 25
                        && Double.Parse(_model["weight", false].ToString()) 
                        >= 12.5
                        && Int32.Parse(_model["speeds", false].ToString()) 
                        >= 16)
                    {
                        // consider bicicleta pentru adulti.
                        _view["type"] = "adults";
                    }
                    else 
                    {
                        // consider bicicleta de alt tip.
                        _view["type"] = "other";
                    }
                }
            };

        /**
         * Definesc un delegat pentru modificarea greutatii.
         */
        private static DControlSetAction ModWeight =
            delegate(Object _weight, IModel _model, IView _view)
            {
                // greutatea este numar real?
                if (_weight is Double)
                {
                    // setez noua greutate.
                    _model["weight", false] = 
                        Double.Parse(_weight.ToString());
                }
                // testez actiunea pentru view
                if (Int32.Parse(_model["dimension", false].ToString()) <= 15
                    && Double.Parse(_model["weight", false].ToString()) <= 7.5
                    && Int32.Parse(_model["speeds", false].ToString()) <= 8)
                {
                    // consider bicicleta pentru copii.
                    _view["type"] = "kids";
                }
                else if (Int32.Parse(_model["dimension", false].ToString()) 
                    >= 25
                    && Double.Parse(_model["weight", false].ToString()) 
                    >= 12.5
                    && Int32.Parse(_model["speeds", false].ToString()) 
                    >= 16)
                {
                    // consider bicicleta pentru adulti.
                    _view["type"] = "adults";
                }
                else
                {
                    // consider bicicleta de alt tip.
                    _view["type"] = "other";
                }
            };

        /**
         * Definesc un delegat pentru cresterea sau scaderea dimensiunii.
         */
        private static DControlSetAction IncDecDimension =
            delegate(Object _direction, IModel _model, IView _view)
            {
                // directia este boolean?
                if (_direction is Boolean)
                {
                    // directia este adevarat?
                    if (Boolean.Parse(_direction.ToString()))
                    {
                        // setez dimensiunea mai mare.
                        _model["dimension", false] = 
                            Int32.Parse(_model["dimension", false].ToString()) 
                            + 1;
                    }
                    else
                    {
                        // setez dimensiunea mai mica.
                        _model["dimension", false] = 
                            Int32.Parse(_model["dimension", false].ToString()) 
                            - 1;
                    }
                }
                // testez actiunea pentru view
                if (Int32.Parse(_model["dimension", false].ToString()) <= 15
                    && Double.Parse(_model["weight", false].ToString()) <= 7.5
                    && Int32.Parse(_model["speeds", false].ToString()) <= 8)
                {
                    // consider bicicleta pentru copii.
                    _view["type"] = "kids";
                }
                else if (Int32.Parse(_model["dimension", false].ToString()) 
                    >= 25
                    && Double.Parse(_model["weight", false].ToString()) 
                    >= 12.5
                    && Int32.Parse(_model["speeds", false].ToString()) 
                    >= 16)
                {
                    // consider bicicleta pentru adulti.
                    _view["type"] = "adults";
                }
                else
                {
                    // consider bicicleta de alt tip.
                    _view["type"] = "other";
                }
            };

        #endregion
    }
}
