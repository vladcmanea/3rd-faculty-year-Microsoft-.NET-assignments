﻿/**
 * nume si prenume: Manea Vlad
 * email: vlad.manea@info.uaic.ro
 * an: III
 * grupa: 6
 * data realizarii: 31 octombrie 2010
 * data laboratorului: 4 noiembrie 2010
 */

using System;
using System.Collections.Generic;
using System.Linq;
using MVC.Control.BaseClasses;
using MVC.Model.Interfaces;
using MVC.View.Interfaces;
using MVC.Control.Interfaces;

/**
 * Spatiul de nume pentru controlurile concrete necesare laboratorului 5.
 */
namespace MVC.Control.ConcreteClasses
{
    /**
     * Clasa produs defineste actiuni pentru toate produsele.
     */
    public class Product: BControl
    {
        /**
         * Definesc regiunea constructorilor.
         */
        #region "Constructors"

        /**
         * Definesc constructorul care primeste un model, 
         * un control si delegatele pentru actiuni de la subclase.
         */
        public Product(IModel _model, IView _view,
            Dictionary<String, DControlSetAction> _actions)
            : base(_model,
                _view, _actions.Concat(new
                Dictionary<String, DControlSetAction>() {
                    {"name", ModName},
                    {"price", IncDecPrice},
                    {"producer", ModProducer},
                    {"stock", IncDecStock}
            }).ToDictionary(e => e.Key, e => e.Value))
        {
            // nu scriu nimic...
        }
        
        #endregion

        /**
         * Declar constrangerile Business.
         */
        #region "Business"

        /**
         * Definesc un delegat pentru setarea numelui NOU sau VECHI.
         * Actualizez datele, daca numele include NEW.
         */
        private static DControlSetAction ModName =
            delegate(Object _name, IModel _model, IView _view)
            {
                // numele este sir de caractere?
                if (_name is String)
                {
                    // setez numele in model.
                    _model["name", false] = _name.ToString();
                    // are prefixul "NEW"?
                    if (_name.ToString().Contains("NEW".ToLower()))
                    {
                        // numele este nou.
                        _view["name"] = "new";
                    }
                    else
                    {
                        // numele este vechi.
                        _view["name"] = "old";
                    }
                }
            };

        /**
         * Definesc un delegat pentru incrementarea/decrementarea pretului.
         */
        private static DControlSetAction IncDecPrice =
            delegate(Object _price, IModel _model, IView _view)
            {
                // pretul este boolean?
                if (_price is Boolean)
                {
                    // este adevarat?
                    if (Boolean.Parse(_price.ToString()))
                    {
                        // cresc pretul
                        _model["price", false] = 
                            Int32.Parse(_model["price", false].ToString()) 
                            + 1;
                    }
                    else
                    {
                        // scad pretul
                        _model["price", false] = 
                            Int32.Parse(_model["price", false].ToString()) 
                            - 1;
                    }
                    // pretul este sub o marja?
                    if (Int32.Parse(_model["price", false].ToString()) < 5)
                    {
                        // scriu ca e ieftin.
                        _view["prodtype"] = "cheap";
                    }
                    else if (Int32.Parse(_model["price", false].ToString()) 
                        > 10)
                    {
                        // scriu ca e scump.
                        _view["prodtype"] = "expensive";
                    }
                    else
                    {
                        // scriu ca e acceptabil.
                        _view["prodtype"] = "acceptable";
                    }
                }
            };

        /**
         * Definesc un delegat pentru modificarea producatorului.
         */
        private static DControlSetAction ModProducer =
            delegate(Object _producer, IModel _model, IView _view)
            {
                // producatorul este sir de caractere?
                if (_producer is String)
                {
                    // setez producatorul
                    _model["producer", false] = _producer.ToString();
                }
            };

        /**
         * Definesc un delegat pentru incrementarea/decrementarea stocului.
         */
        private static DControlSetAction IncDecStock =
            delegate(Object _stock, IModel _model, IView _view)
            {
                // stocul este boolean?
                if (_stock is Boolean)
                {
                    // este adevarat?
                    if (Boolean.Parse(_stock.ToString()))
                    {
                        // cresc stocul
                        _model["stock", false] = 
                            Int32.Parse(_model["stock", false].ToString()) 
                            + 1;
                    }
                    else
                    {
                        // scad stocul
                        _model["stock", false] = 
                            Int32.Parse(_model["stock", false].ToString()) 
                            - 1;
                    }
                }
            };
        
        #endregion
    }
}
