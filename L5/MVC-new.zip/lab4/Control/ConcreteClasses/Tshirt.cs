﻿/**
 * nume si prenume: Manea Vlad
 * email: vlad.manea@info.uaic.ro
 * an: III
 * grupa: 6
 * data realizarii: 31 octombrie 2010
 * data laboratorului: 4 noiembrie 2010
 */

using System;
using System.Collections.Generic;
using System.Linq;
using MVC.Model.Interfaces;
using MVC.View.Interfaces;
using MVC.Control.Interfaces;

/**
 * Spatiul de nume pentru controlurile concrete necesare laboratorului 5.
 */
namespace MVC.Control.ConcreteClasses
{
    /**
     * Clasa tricou defineste actiuni pentru toate tricourile.
     */
    public class Tshirt : Product
    {
        /**
         * Definesc regiunea constructorilor.
         */
        #region "Constructors"

        /**
         * Definesc constructorul care primeste un model, 
         * un control si delegatele pentru actiuni de la subclase.
         */
        public Tshirt(IModel _model, IView _view,
            Dictionary<String, DControlSetAction> _actions)
            : base(_model,
                _view, _actions.Concat(new
                Dictionary<String, DControlSetAction>() {
                    {"size", IncDecSize},
                    {"color", ModColor},
                    {"material", ModMaterial}
            }).ToDictionary(e => e.Key, e => e.Value))
        {
            // nu scriu nimic...
        }
        
        #endregion

        /**
         * Declar constrangerile Business.
         */
        #region "Business"

        /**
         * Definesc un delegat pentru modificarea culorii.
         */
        private static DControlSetAction ModColor =
            delegate(Object _color, IModel _model, IView _view)
            {
                // culoarea este sir de caractere?
                if (_color is String)
                {
                    // setez noua culoare.
                    _model["color", false] = _color.ToString();
                    // setez culoare pentru cine?
                    if (_model["color", false].ToString() == "Red")
                    {
                        // setez culoare pentru fata.
                        _view["type"] = "Girl";
                    }
                    else if (_model["color", false].ToString() == "Blue")
                    {
                        // setez culoare pentru baiat.
                        _view["type"] = "Boy";
                    }
                    else if (_model["color", false].ToString() == "Black")
                    {
                        // setez culoare pentru detectiv.
                        _view["type"] = "Detective";
                    }
                    else
                    {
                        // setez culoare pentru ecologist.
                        _view["type"] = "Ecologist";
                    }
                }
            };

        /**
         * Definesc un delegat pentru modificarea materialului.
         */
        private static DControlSetAction ModMaterial =
            delegate(Object _material, IModel _model, IView _view)
            {
                // materialul este sir de caractere?
                if (_material is String)
                {
                    // setez noul material.
                    _model["material", false] = _material.ToString();
                }
            };

        /**
         * Definesc un delegat pentru cresterea sau scaderea dimensiunii.
         * Actualizez datele.
         */
        private static DControlSetAction IncDecSize =
            delegate(Object _direction, IModel _model, IView _view)
            {
                // directia este boolean?
                if (_direction is Boolean)
                {
                    // directia este adevarat?
                    if (Boolean.Parse(_direction.ToString()))
                    {
                        // setez dimensiunea mai mare.
                        _model["size", false] = 
                            Int32.Parse(_model["size", false].ToString()) + 1;
                    }
                    else
                    {
                        // setez dimensiuniea mai mica.
                        _model["size", false] = 
                            Int32.Parse(_model["size", false].ToString()) - 1;
                    }
                }
            };

        #endregion
    }
}
