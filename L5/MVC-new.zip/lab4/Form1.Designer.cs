﻿/**
 * nume si prenume: Manea Vlad
 * email: vlad.manea@info.uaic.ro
 * an: III
 * grupa: 6
 * data realizarii: 31 octombrie 2010
 * data laboratorului: 4 noiembrie 2010
 */

namespace MVC
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.product1 = new MVC.View.ConcreteComponents.Product();
            this.bicycle1 = new MVC.View.ConcreteComponents.Bicycle();
            this.refreshment1 = new MVC.View.ConcreteComponents.Refreshment();
            this.tshirt1 = new MVC.View.ConcreteComponents.Tshirt();
            this.product2 = new MVC.View.ConcreteComponents.Product();
            this.product3 = new MVC.View.ConcreteComponents.Product();
            this.SuspendLayout();
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(13, 13);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(912, 43);
            this.listBox1.TabIndex = 0;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // product1
            // 
            this.product1.Control = null;
            this.product1.Location = new System.Drawing.Point(13, 62);
            this.product1.Model = null;
            this.product1.Name = "product1";
            this.product1.Size = new System.Drawing.Size(300, 250);
            this.product1.TabIndex = 1;
            // 
            // bicycle1
            // 
            this.bicycle1.Control = null;
            this.bicycle1.Location = new System.Drawing.Point(13, 318);
            this.bicycle1.Model = null;
            this.bicycle1.Name = "bicycle1";
            this.bicycle1.Size = new System.Drawing.Size(300, 225);
            this.bicycle1.TabIndex = 2;
            // 
            // refreshment1
            // 
            this.refreshment1.Control = null;
            this.refreshment1.Location = new System.Drawing.Point(319, 318);
            this.refreshment1.Model = null;
            this.refreshment1.Name = "refreshment1";
            this.refreshment1.Size = new System.Drawing.Size(300, 225);
            this.refreshment1.TabIndex = 3;
            // 
            // tshirt1
            // 
            this.tshirt1.Control = null;
            this.tshirt1.Location = new System.Drawing.Point(625, 318);
            this.tshirt1.Model = null;
            this.tshirt1.Name = "tshirt1";
            this.tshirt1.Size = new System.Drawing.Size(300, 225);
            this.tshirt1.TabIndex = 4;
            // 
            // product2
            // 
            this.product2.Control = null;
            this.product2.Location = new System.Drawing.Point(319, 62);
            this.product2.Model = null;
            this.product2.Name = "product2";
            this.product2.Size = new System.Drawing.Size(300, 250);
            this.product2.TabIndex = 5;
            // 
            // product3
            // 
            this.product3.Control = null;
            this.product3.Location = new System.Drawing.Point(625, 62);
            this.product3.Model = null;
            this.product3.Name = "product3";
            this.product3.Size = new System.Drawing.Size(300, 250);
            this.product3.TabIndex = 6;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(938, 565);
            this.Controls.Add(this.product3);
            this.Controls.Add(this.product2);
            this.Controls.Add(this.tshirt1);
            this.Controls.Add(this.refreshment1);
            this.Controls.Add(this.bicycle1);
            this.Controls.Add(this.product1);
            this.Controls.Add(this.listBox1);
            this.Name = "Form1";
            this.Text = "MVC";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        public System.Windows.Forms.ListBox listBox1;
        private View.ConcreteComponents.Product product1;
        private View.ConcreteComponents.Bicycle bicycle1;
        private View.ConcreteComponents.Refreshment refreshment1;
        private View.ConcreteComponents.Tshirt tshirt1;
        private View.ConcreteComponents.Product product2;
        private View.ConcreteComponents.Product product3;

    }
}

