﻿/**
 * nume si prenume: Manea Vlad
 * email: vlad.manea@info.uaic.ro
 * an: III
 * grupa: 6
 * data realizarii: 31 octombrie 2010
 * data laboratorului: 4 noiembrie 2010
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MVC.Model.Interfaces;
using MVC.Control.Interfaces;

/**
 * Spatiul de nume pentru interfetele necesare laboratorului 5.
 */
namespace MVC.View.Interfaces
{
    // declar un delegat pentru actiune.        
    public delegate void DViewAction(Object _object, IView _view);

    /**
     * Interfata IView este utilizata pentru a stabili contractul intre view 
     * si celelalte doua componente: model si control. Am proiectat viewul
     * sa permita proprietati dinamice. 
     * 
     * Viewul isi cunoaste si controlul, si modelul care il notifica.
     */
    public interface IView
    {
        /**
         * Impun sa se poata realiza (desigur, public) actiuni asupra 
         * viewului prin view[numeactiune]. Acest lucru este util pentru 
         * proprietati dinamice, necunoscute a priori.
         */
        #region "Actions"

        /**
         * Cand se apeleaza view[numeactiune] = obiect, viewul va 
         * intelege ca se aplica o actiune si se transmite un obiect 
         * (optional). In aceasta metoda din aceasta clasa abstracta 
         * nu se intampla nimic, deoarece actiunile vor fi definite 
         * in clase concrete.
         */
        Object this[string _action]
        {
            set;
        }

        #endregion

        /**
         * Impun modelul de proiectare Observer. Modelul are o lista de
         * elemente ce implementeaza interfata pentru view (IView) care vor
         * fi anuntate dupa ce o proprietate a modelului va fi modificata.
         * Functiile standard sunt cele de adaugare, stergere si notificare.
         */
        #region "Management"

        /**
         * Declar functia de notificare a viewului dinspre model.
         */
        void UpdateObserver(IModel _model);

        /**
         * Declar setter getter pentru control.
         */
        IControl Control
        {
            set;
            get;
        }

        /**
         * Declar setter getter pentru model.
         */
        IModel Model
        {
            set;
            get;
        }

        #endregion
    }
}
