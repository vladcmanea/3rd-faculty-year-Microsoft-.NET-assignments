﻿/**
 * nume si prenume: Manea Vlad
 * email: vlad.manea@info.uaic.ro
 * an: III
 * grupa: 6
 * data realizarii: 31 octombrie 2010
 * data laboratorului: 4 noiembrie 2010
 */

namespace MVC.View.ConcreteComponents
{
    partial class Product
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.producttype = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.incstock = new System.Windows.Forms.Button();
            this.decstock = new System.Windows.Forms.Button();
            this.incprice = new System.Windows.Forms.Button();
            this.decprice = new System.Windows.Forms.Button();
            this.stock = new System.Windows.Forms.TextBox();
            this.price = new System.Windows.Forms.TextBox();
            this.producer = new System.Windows.Forms.TextBox();
            this.name = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // producttype
            // 
            this.producttype.Location = new System.Drawing.Point(25, 206);
            this.producttype.Name = "producttype";
            this.producttype.ReadOnly = true;
            this.producttype.Size = new System.Drawing.Size(251, 20);
            this.producttype.TabIndex = 45;
            this.producttype.Text = "acceptable";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(140, 145);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(33, 13);
            this.label4.TabIndex = 44;
            this.label4.Text = "stock";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(143, 102);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(30, 13);
            this.label3.TabIndex = 43;
            this.label3.Text = "price";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(134, 63);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 13);
            this.label2.TabIndex = 42;
            this.label2.Text = "producer";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(140, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(33, 13);
            this.label1.TabIndex = 41;
            this.label1.Text = "name";
            // 
            // incstock
            // 
            this.incstock.Location = new System.Drawing.Point(207, 165);
            this.incstock.Name = "incstock";
            this.incstock.Size = new System.Drawing.Size(69, 23);
            this.incstock.TabIndex = 40;
            this.incstock.Text = "increase";
            this.incstock.UseVisualStyleBackColor = true;
            this.incstock.Click += new System.EventHandler(this.incstock_Click);
            // 
            // decstock
            // 
            this.decstock.Location = new System.Drawing.Point(25, 165);
            this.decstock.Name = "decstock";
            this.decstock.Size = new System.Drawing.Size(75, 23);
            this.decstock.TabIndex = 39;
            this.decstock.Text = "decrease";
            this.decstock.UseVisualStyleBackColor = true;
            this.decstock.Click += new System.EventHandler(this.decstock_Click);
            // 
            // incprice
            // 
            this.incprice.Location = new System.Drawing.Point(207, 122);
            this.incprice.Name = "incprice";
            this.incprice.Size = new System.Drawing.Size(69, 23);
            this.incprice.TabIndex = 38;
            this.incprice.Text = "increase";
            this.incprice.UseVisualStyleBackColor = true;
            this.incprice.Click += new System.EventHandler(this.incprice_Click);
            // 
            // decprice
            // 
            this.decprice.Location = new System.Drawing.Point(25, 119);
            this.decprice.Name = "decprice";
            this.decprice.Size = new System.Drawing.Size(75, 23);
            this.decprice.TabIndex = 37;
            this.decprice.Text = "decrease";
            this.decprice.UseVisualStyleBackColor = true;
            this.decprice.Click += new System.EventHandler(this.decprice_Click);
            // 
            // stock
            // 
            this.stock.Location = new System.Drawing.Point(106, 165);
            this.stock.Name = "stock";
            this.stock.ReadOnly = true;
            this.stock.Size = new System.Drawing.Size(95, 20);
            this.stock.TabIndex = 36;
            // 
            // price
            // 
            this.price.Location = new System.Drawing.Point(106, 122);
            this.price.Name = "price";
            this.price.ReadOnly = true;
            this.price.Size = new System.Drawing.Size(95, 20);
            this.price.TabIndex = 35;
            // 
            // producer
            // 
            this.producer.Location = new System.Drawing.Point(25, 79);
            this.producer.Name = "producer";
            this.producer.Size = new System.Drawing.Size(251, 20);
            this.producer.TabIndex = 34;
            this.producer.Leave += new System.EventHandler(this.producer_LostFocus);
            // 
            // name
            // 
            this.name.Location = new System.Drawing.Point(25, 40);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(251, 20);
            this.name.TabIndex = 33;
            this.name.Leave += new System.EventHandler(this.name_LostFocus);
            // 
            // Product
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.producttype);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.incstock);
            this.Controls.Add(this.decstock);
            this.Controls.Add(this.incprice);
            this.Controls.Add(this.decprice);
            this.Controls.Add(this.stock);
            this.Controls.Add(this.price);
            this.Controls.Add(this.producer);
            this.Controls.Add(this.name);
            this.Name = "Product";
            this.Size = new System.Drawing.Size(300, 250);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox producttype;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button incstock;
        private System.Windows.Forms.Button decstock;
        private System.Windows.Forms.Button incprice;
        private System.Windows.Forms.Button decprice;
        private System.Windows.Forms.TextBox stock;
        private System.Windows.Forms.TextBox price;
        private System.Windows.Forms.TextBox producer;
        private System.Windows.Forms.TextBox name;
    }
}
