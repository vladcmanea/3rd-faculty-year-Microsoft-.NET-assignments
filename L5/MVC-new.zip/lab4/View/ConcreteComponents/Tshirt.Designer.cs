﻿/**
 * nume si prenume: Manea Vlad
 * email: vlad.manea@info.uaic.ro
 * an: III
 * grupa: 6
 * data realizarii: 31 octombrie 2010
 * data laboratorului: 4 noiembrie 2010
 */

using System.Windows.Forms;
namespace MVC.View.ConcreteComponents
{
    partial class Tshirt
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.material = new System.Windows.Forms.DomainUpDown();
            this.color = new System.Windows.Forms.DomainUpDown();
            this.label15 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.tshirttype = new System.Windows.Forms.TextBox();
            this.incsize = new System.Windows.Forms.Button();
            this.decsize = new System.Windows.Forms.Button();
            this.size = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // material
            // 
            this.material.Items.Add("Wool");
            this.material.Items.Add("Cotton");
            this.material.Items.Add("Polymer");
            this.material.Location = new System.Drawing.Point(23, 115);
            this.material.Name = "material";
            this.material.ReadOnly = true;
            this.material.Size = new System.Drawing.Size(252, 20);
            this.material.TabIndex = 38;
            this.material.SelectedItemChanged += new System.EventHandler(this.material_SelectedItemChanged);
            // 
            // color
            // 
            this.color.Items.Add("Red");
            this.color.Items.Add("Blue");
            this.color.Items.Add("Green");
            this.color.Items.Add("Black");
            this.color.Location = new System.Drawing.Point(23, 72);
            this.color.Name = "color";
            this.color.ReadOnly = true;
            this.color.Size = new System.Drawing.Size(252, 20);
            this.color.TabIndex = 37;
            this.color.SelectedItemChanged += new System.EventHandler(this.color_SelectedItemChanged);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(129, 99);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(43, 13);
            this.label15.TabIndex = 36;
            this.label15.Text = "material";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(134, 55);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(30, 13);
            this.label13.TabIndex = 34;
            this.label13.Text = "color";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(139, 9);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(25, 13);
            this.label11.TabIndex = 35;
            this.label11.Text = "size";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(97, 152);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(111, 13);
            this.label9.TabIndex = 33;
            this.label9.Text = "business observations";
            // 
            // tshirttype
            // 
            this.tshirttype.Location = new System.Drawing.Point(23, 168);
            this.tshirttype.Name = "tshirttype";
            this.tshirttype.ReadOnly = true;
            this.tshirttype.Size = new System.Drawing.Size(252, 20);
            this.tshirttype.TabIndex = 32;
            this.tshirttype.Text = "Other";
            // 
            // incsize
            // 
            this.incsize.Location = new System.Drawing.Point(206, 25);
            this.incsize.Name = "incsize";
            this.incsize.Size = new System.Drawing.Size(69, 23);
            this.incsize.TabIndex = 31;
            this.incsize.Text = "increase";
            this.incsize.UseVisualStyleBackColor = true;
            this.incsize.Click += new System.EventHandler(this.incsize_Click);
            // 
            // decsize
            // 
            this.decsize.Location = new System.Drawing.Point(23, 25);
            this.decsize.Name = "decsize";
            this.decsize.Size = new System.Drawing.Size(75, 23);
            this.decsize.TabIndex = 30;
            this.decsize.Text = "decrease";
            this.decsize.UseVisualStyleBackColor = true;
            this.decsize.Click += new System.EventHandler(this.decsize_Click);
            // 
            // size
            // 
            this.size.Enabled = false;
            this.size.Location = new System.Drawing.Point(100, 25);
            this.size.Name = "size";
            this.size.Size = new System.Drawing.Size(100, 20);
            this.size.TabIndex = 29;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(115, 194);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 39;
            this.button2.Text = "OK";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // Tshirt
            // 
            this.Controls.Add(this.button2);
            this.Controls.Add(this.material);
            this.Controls.Add(this.color);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.tshirttype);
            this.Controls.Add(this.incsize);
            this.Controls.Add(this.decsize);
            this.Controls.Add(this.size);
            this.Name = "Tshirt";
            this.Size = new System.Drawing.Size(300, 225);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private DomainUpDown material;
        private DomainUpDown color;
        private Label label15;
        private Label label13;
        private Label label11;
        private Label label9;
        private TextBox tshirttype;
        private Button incsize;
        private Button decsize;
        private Button button2;
        private TextBox size;

        #endregion
    }
}
