﻿/**
 * nume si prenume: Manea Vlad
 * email: vlad.manea@info.uaic.ro
 * an: III
 * grupa: 6
 * data realizarii: 31 octombrie 2010
 * data laboratorului: 4 noiembrie 2010
 */

namespace MVC.View.ConcreteComponents
{
    partial class Bicycle
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.bicycletype = new System.Windows.Forms.TextBox();
            this.weight = new System.Windows.Forms.TextBox();
            this.incdimension = new System.Windows.Forms.Button();
            this.decdimension = new System.Windows.Forms.Button();
            this.dimension = new System.Windows.Forms.TextBox();
            this.incspeeds = new System.Windows.Forms.Button();
            this.decspeeds = new System.Windows.Forms.Button();
            this.speeds = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(123, 193);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(60, 23);
            this.button1.TabIndex = 49;
            this.button1.Text = "OK";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(99, 151);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(111, 13);
            this.label8.TabIndex = 48;
            this.label8.Text = "business observations";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(136, 98);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(38, 13);
            this.label7.TabIndex = 47;
            this.label7.Text = "weight";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(128, 54);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(54, 13);
            this.label6.TabIndex = 46;
            this.label6.Text = "dimension";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(120, 8);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(63, 13);
            this.label5.TabIndex = 45;
            this.label5.Text = "# of speeds";
            // 
            // bicycletype
            // 
            this.bicycletype.Location = new System.Drawing.Point(24, 167);
            this.bicycletype.Name = "bicycletype";
            this.bicycletype.ReadOnly = true;
            this.bicycletype.Size = new System.Drawing.Size(252, 20);
            this.bicycletype.TabIndex = 44;
            this.bicycletype.Text = "other";
            // 
            // weight
            // 
            this.weight.Location = new System.Drawing.Point(25, 114);
            this.weight.Name = "weight";
            this.weight.Size = new System.Drawing.Size(252, 20);
            this.weight.TabIndex = 43;
            this.weight.Leave += new System.EventHandler(this.weight_LostFocus);
            // 
            // incdimension
            // 
            this.incdimension.Location = new System.Drawing.Point(208, 70);
            this.incdimension.Name = "incdimension";
            this.incdimension.Size = new System.Drawing.Size(69, 23);
            this.incdimension.TabIndex = 42;
            this.incdimension.Text = "increase";
            this.incdimension.UseVisualStyleBackColor = true;
            this.incdimension.Click += new System.EventHandler(this.incdimension_Click);
            // 
            // decdimension
            // 
            this.decdimension.Location = new System.Drawing.Point(25, 70);
            this.decdimension.Name = "decdimension";
            this.decdimension.Size = new System.Drawing.Size(75, 23);
            this.decdimension.TabIndex = 41;
            this.decdimension.Text = "decrease";
            this.decdimension.UseVisualStyleBackColor = true;
            this.decdimension.Click += new System.EventHandler(this.decdimension_Click);
            // 
            // dimension
            // 
            this.dimension.Enabled = false;
            this.dimension.Location = new System.Drawing.Point(102, 70);
            this.dimension.Name = "dimension";
            this.dimension.Size = new System.Drawing.Size(100, 20);
            this.dimension.TabIndex = 40;
            // 
            // incspeeds
            // 
            this.incspeeds.Location = new System.Drawing.Point(207, 24);
            this.incspeeds.Name = "incspeeds";
            this.incspeeds.Size = new System.Drawing.Size(69, 23);
            this.incspeeds.TabIndex = 39;
            this.incspeeds.Text = "increase";
            this.incspeeds.UseVisualStyleBackColor = true;
            this.incspeeds.Click += new System.EventHandler(this.incspeeds_Click);
            // 
            // decspeeds
            // 
            this.decspeeds.Location = new System.Drawing.Point(24, 24);
            this.decspeeds.Name = "decspeeds";
            this.decspeeds.Size = new System.Drawing.Size(75, 23);
            this.decspeeds.TabIndex = 38;
            this.decspeeds.Text = "decrease";
            this.decspeeds.UseVisualStyleBackColor = true;
            this.decspeeds.Click += new System.EventHandler(this.decspeeds_Click);
            // 
            // speeds
            // 
            this.speeds.Enabled = false;
            this.speeds.Location = new System.Drawing.Point(101, 24);
            this.speeds.Name = "speeds";
            this.speeds.Size = new System.Drawing.Size(100, 20);
            this.speeds.TabIndex = 37;
            // 
            // Bicycle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.bicycletype);
            this.Controls.Add(this.weight);
            this.Controls.Add(this.incdimension);
            this.Controls.Add(this.decdimension);
            this.Controls.Add(this.dimension);
            this.Controls.Add(this.incspeeds);
            this.Controls.Add(this.decspeeds);
            this.Controls.Add(this.speeds);
            this.Name = "Bicycle";
            this.Size = new System.Drawing.Size(300, 225);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        public System.Windows.Forms.TextBox bicycletype;
        public System.Windows.Forms.TextBox weight;
        public System.Windows.Forms.Button incdimension;
        public System.Windows.Forms.Button decdimension;
        public System.Windows.Forms.TextBox dimension;
        public System.Windows.Forms.Button incspeeds;
        public System.Windows.Forms.Button decspeeds;
        public System.Windows.Forms.TextBox speeds;
    }
}
