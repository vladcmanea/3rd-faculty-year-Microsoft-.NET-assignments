﻿/**
 * nume si prenume: Manea Vlad
 * email: vlad.manea@info.uaic.ro
 * an: III
 * grupa: 6
 * data realizarii: 31 octombrie 2010
 * data laboratorului: 4 noiembrie 2010
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MVC.View.Interfaces;
using MVC.Model.Interfaces;
using MVC.Control.Interfaces;

namespace MVC.View.ConcreteComponents
{
    public partial class Refreshment : UserControl, IView
    {
        /**
         * Definesc regiunea constructorilor.
         */
        #region "Constructors"

        /**
         * Definesc constructorul fara parametri.
         */
        public Refreshment()
        {
            InitializeComponent();
            // setez actiunile.
            actions = new Dictionary<string, DViewAction>() 
            { {"quantity", ModQuantityRefreshment} };
        }

        /**
         * Definesc constructorul care primeste un model si un control.
         */
        public Refreshment(IModel _model, IControl _control,
            Dictionary<String, DViewAction> _actions):this()
        {
            // setez modelul.
            Model = _model;
            // setez controlul.
            Control = _control;
            // setez actiunile.
            actions = actions.Concat(_actions).ToDictionary(e => e.Key, 
                 e => e.Value);

            _control.Model = _model;
            _control.View = this;
            UpdateObserver(_model);
        }

        #endregion

        /**
         * Impun sa se poata realiza (desigur, public) actiuni asupra 
         * viewului prin view[numeactiune]. Acest lucru este util pentru 
         * proprietati dinamice, necunoscute a priori.
         */
        #region "Actions"

        // retin proprietatile intr-o structura de date de tip dictionar.
        // tuplul contine: <valoare_implicita, delegat>
        private Dictionary<String, DViewAction> actions =
            new Dictionary<String, DViewAction>();

        /**
         * Cand se apeleaza view[numeactiune] = obiect, viewul va 
         * intelege ca se aplica o actiune si se transmite un obiect 
         * (optional). In aceasta metoda din aceasta clasa abstracta 
         * nu se intampla nimic, deoarece actiunile vor fi definite 
         * in clase concrete.
         */
        public Object this[string _action]
        {
            set
            {
                // exista actiunea cu numele respectiv?
                if (actions.ContainsKey(_action))
                {
                    // executa actiunea.
                    actions[_action](value, this);
                }
            }
        }

        /**
         * Definesc un delegat pentru modificarea cantitatii.
         */
        private static DViewAction ModQuantityRefreshment =
            delegate(Object _quantity, IView _view)
            {
                if (_view is MVC.View.ConcreteComponents.Refreshment)
                {
                    ((MVC.View.ConcreteComponents.Refreshment)_view).refreshmentquantity.Text =
                        _quantity.ToString();
                }
            };

        #endregion

        /**
         * Impun modelul de proiectare Observer. Modelul are o lista de
         * elemente ce implementeaza interfata pentru view (IView) care vor
         * fi anuntate dupa ce o proprietate a modelului va fi modificata.
         * Functiile standard sunt cele de adaugare, stergere si notificare.
         * 
         * Se permite doar schimbarea controlului si modelului pentru view.
         */
        #region "Management"

        // retin controlul.
        private IControl control = null;

        // retin modelul.
        private IModel model = null;

        /**
         * Definesc functia de notificare a viewului dinspre model.
         */
        public void UpdateObserver(IModel _model)
        {
            // actualizez pentru suc.
            quantity.Text = _model["quantity", false].ToString();
            warranty.Text = _model["warranty", false].ToString();
        }

        /**
         * Definesc getter setter pentru control.
         */
        public IControl Control
        {
            set
            {
                // setez controlul.
                control = value;
                // setez viewul controlului.
                if (control != null)
                {
                    control.View = this;
                }
            }
            get
            {
                // intorc controlul.
                return control;
            }
        }

        /**
         * Definesc setter getter pentru model.
         */
        public IModel Model
        {
            set
            {
                // daca aveam un model de mai demult,
                if (model != null)
                {
                    // ma elimin din lista lui de observatori.
                    model.UnregisterObserver(this);
                }
                // setez modelul nou.
                model = value;
                // inregistrez viewul curent la modelul nou.
                if (model != null)
                {
                    model.RegisterObserver(this);
                }
            }
            get
            {
                // intorc modelul.
                return model;
            }
        }

        #endregion

        /**
         * Definesc regiunea evenimentelor din interfata grafica.
         */
        #region "Events"

        private void warranty_LostFocus(object sender, EventArgs e)
        {
            DateTime val;
            if (DateTime.TryParse(warranty.Text, out val))
            {
                if (Control != null)
                {
                    Control["warranty"] = val;
                }
            }
            else
            {
                if (Model != null)
                {
                    warranty.Text =
                        Model["warranty", false].ToString();
                }
            }
        }

        private void quantity_LostFocus(object sender, EventArgs e)
        {
            Double val;
            if (Double.TryParse(quantity.Text, out val))
            {
                if (Control != null)
                {
                    Control["quantity"] = val;
                }
            }
            else
            {
                if (Model != null)
                {
                    quantity.Text =
                        Model["quantity", false].ToString();
                }
            }
        }

        #endregion
    }
}
