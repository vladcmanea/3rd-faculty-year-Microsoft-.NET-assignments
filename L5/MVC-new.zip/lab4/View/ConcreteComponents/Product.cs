﻿/**
 * nume si prenume: Manea Vlad
 * email: vlad.manea@info.uaic.ro
 * an: III
 * grupa: 6
 * data realizarii: 31 octombrie 2010
 * data laboratorului: 4 noiembrie 2010
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MVC.Control.Interfaces;
using MVC.Model.Interfaces;
using MVC.View.Interfaces;

namespace MVC.View.ConcreteComponents
{
    public partial class Product : UserControl, IView
    {
        /**
          * Definesc regiunea constructorilor.
          */
        #region "Constructors"

        /**
         * Definesc constructorul fara parametri.
         */
        public Product()
        {
            InitializeComponent();
            // setez actiunile.
            actions = new Dictionary<string, DViewAction>() 
            { {"prodtype", ModTypeProduct} };
        }

        /**
         * Definesc constructorul care primeste un model, un control si
         * o serie de actiuni.
         */
        public Product(IModel _model, IControl _control,
            Dictionary<String, DViewAction> _actions):this()
        {
            // setez modelul.
            Model = _model;
            // setez controlul.
            Control = _control;
            // setez actiunile.
            actions = actions.Concat(_actions).ToDictionary(e => e.Key, 
                e => e.Value);

            _control.Model = _model;
            _control.View = this;
            UpdateObserver(_model);
        }

        #endregion

        /**
         * Impun sa se poata realiza (desigur, public) actiuni asupra 
         * viewului prin view[numeactiune]. Acest lucru este util pentru 
         * proprietati dinamice, necunoscute a priori.
         */
        #region "Actions"

        // retin proprietatile intr-o structura de date de tip dictionar.
        // tuplul contine: <valoare_implicita, delegat>
        private Dictionary<String, DViewAction> actions =
            new Dictionary<String, DViewAction>();

        /**
         * Cand se apeleaza view[numeactiune] = obiect, viewul va 
         * intelege ca se aplica o actiune si se transmite un obiect 
         * (optional). In aceasta metoda din aceasta clasa abstracta 
         * nu se intampla nimic, deoarece actiunile vor fi definite 
         * in clase concrete.
         */
        public Object this[string _action]
        {
            set
            {
                // exista actiunea cu numele respectiv?
                if (actions.ContainsKey(_action))
                {
                    // executa actiunea.
                    actions[_action](value, this);
                }
            }
        }

        /**
         * Declar un delegat pentru modificarea produsului.
         * Acesta va fi apelat din view.
         */
        private static DViewAction ModTypeProduct =
            delegate(Object _type, IView _view)
            {
                if (_view is MVC.View.ConcreteComponents.Product)
                {
                    ((Product)_view).producttype.Text =
                        _type.ToString();
                }
            };

        #endregion

        /**
         * Impun modelul de proiectare Observer. Modelul are o lista de
         * elemente ce implementeaza interfata pentru view (IView) care vor
         * fi anuntate dupa ce o proprietate a modelului va fi modificata.
         * Functiile standard sunt cele de adaugare, stergere si notificare.
         */
        #region "Management"

        // retin controlul.
        private IControl control = null;

        // retin modelul.
        private IModel model = null;

        /**
         * Definesc functia de notificare a viewului dinspre model.
         */
        public void UpdateObserver(IModel _model)
        {
            // actualizez pentru produs.
            name.Text =
                _model["name", false].ToString();
            producer.Text =
                _model["producer", false].ToString();
            stock.Text =
                _model["stock", false].ToString();
            price.Text =
                _model["price", false].ToString();
        }

        /**
         * Declar getter setter pentru control.
         */
        public IControl Control
        {
            set
            {
                // setez controlul.
                control = value;
                // setez viewul controlului.
                if (control != null)
                {
                    control.View = this;
                }
            }
            get
            {
                // intorc controlul.
                return control;
            }
        }

        /**
         * Declar getter setter pentru model.
         */
        public IModel Model
        {
            set
            {
                // daca aveam un model de mai demult,
                if (model != null)
                {
                    // ma elimin din lista lui de observatori.
                    model.UnregisterObserver(this);
                }
                // setez modelul nou.
                model = value;
                // inregistrez viewul curent la modelul nou.
                if (model != null)
                {
                    model.RegisterObserver(this);
                }
            }
            get
            {
                // intorc modelul.
                return model;
            }
        }

        #endregion

        /**
         * Definesc regiunea evenimentelor din interfata grafica.
         */
        #region "Events"

        private void name_LostFocus(object sender, EventArgs e)
        {
            if (Control != null)
            {
                Control["name"] =
                    name.Text.ToString();
            }
        }

        private void producer_LostFocus(object sender, EventArgs e)
        {
            if (Control != null)
            {
                Control["producer"] =
                    producer.Text.ToString();
            }
        }

        private void decprice_Click(object sender, EventArgs e)
        {
            if (Control != null)
            { 
                Control["price"] = false; 
            }
        }

        private void incprice_Click(object sender, EventArgs e)
        {
            if (Control != null)
            {
                Control["price"] = true;
            }
        }

        private void decstock_Click(object sender, EventArgs e)
        {
            if (Control != null)
            {
                Control["stock"] = false;
            }
        }

        private void incstock_Click(object sender, EventArgs e)
        {
            if (Control != null)
            {
                Control["stock"] = true;
            }
        }

        #endregion
    }
}
