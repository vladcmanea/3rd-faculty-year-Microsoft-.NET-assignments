﻿/**
 * nume si prenume: Manea Vlad
 * email: vlad.manea@info.uaic.ro
 * an: III
 * grupa: 6
 * data realizarii: 31 octombrie 2010
 * data laboratorului: 4 noiembrie 2010
 */

using System.Windows.Forms;
namespace MVC.View.ConcreteComponents
{
    partial class Refreshment
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button3 = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.refreshmentquantity = new System.Windows.Forms.TextBox();
            this.quantity = new System.Windows.Forms.TextBox();
            this.warranty = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(112, 193);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 36;
            this.button3.Text = "OK";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(129, 54);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(44, 13);
            this.label14.TabIndex = 35;
            this.label14.Text = "quantity";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(129, 8);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(47, 13);
            this.label12.TabIndex = 33;
            this.label12.Text = "warranty";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(94, 151);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(111, 13);
            this.label10.TabIndex = 34;
            this.label10.Text = "business observations";
            // 
            // refreshmentquantity
            // 
            this.refreshmentquantity.Location = new System.Drawing.Point(24, 167);
            this.refreshmentquantity.Name = "refreshmentquantity";
            this.refreshmentquantity.ReadOnly = true;
            this.refreshmentquantity.Size = new System.Drawing.Size(252, 20);
            this.refreshmentquantity.TabIndex = 32;
            this.refreshmentquantity.Text = "ok";
            // 
            // quantity
            // 
            this.quantity.Location = new System.Drawing.Point(25, 70);
            this.quantity.Name = "quantity";
            this.quantity.Size = new System.Drawing.Size(252, 20);
            this.quantity.TabIndex = 31;
            this.quantity.Leave += new System.EventHandler(this.quantity_LostFocus);
            // 
            // warranty
            // 
            this.warranty.Location = new System.Drawing.Point(25, 24);
            this.warranty.Name = "warranty";
            this.warranty.Size = new System.Drawing.Size(252, 20);
            this.warranty.TabIndex = 30;
            this.warranty.Leave += new System.EventHandler(this.warranty_LostFocus);
            // 
            // Refreshment
            // 
            this.Controls.Add(this.button3);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.refreshmentquantity);
            this.Controls.Add(this.quantity);
            this.Controls.Add(this.warranty);
            this.Name = "Refreshment";
            this.Size = new System.Drawing.Size(300, 225);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button button3;
        private Label label14;
        private Label label12;
        private Label label10;
        private TextBox refreshmentquantity;
        private TextBox quantity;
        private TextBox warranty;
    }
}
