﻿namespace lab5
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.Bicycle = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.bicycletype = new System.Windows.Forms.TextBox();
            this.weight = new System.Windows.Forms.TextBox();
            this.incdimension = new System.Windows.Forms.Button();
            this.decdimension = new System.Windows.Forms.Button();
            this.dimension = new System.Windows.Forms.TextBox();
            this.incspeeds = new System.Windows.Forms.Button();
            this.decspeeds = new System.Windows.Forms.Button();
            this.speeds = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Refreshment = new System.Windows.Forms.Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.refreshmentquantity = new System.Windows.Forms.TextBox();
            this.quantity = new System.Windows.Forms.TextBox();
            this.warranty = new System.Windows.Forms.TextBox();
            this.Product = new System.Windows.Forms.Panel();
            this.producttype = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.incstock = new System.Windows.Forms.Button();
            this.decstock = new System.Windows.Forms.Button();
            this.incprice = new System.Windows.Forms.Button();
            this.decprice = new System.Windows.Forms.Button();
            this.stock = new System.Windows.Forms.TextBox();
            this.price = new System.Windows.Forms.TextBox();
            this.producer = new System.Windows.Forms.TextBox();
            this.name = new System.Windows.Forms.TextBox();
            this.size = new System.Windows.Forms.TextBox();
            this.decsize = new System.Windows.Forms.Button();
            this.incsize = new System.Windows.Forms.Button();
            this.tshirttype = new System.Windows.Forms.TextBox();
            this.Tshirt = new System.Windows.Forms.Panel();
            this.label15 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.color = new System.Windows.Forms.DomainUpDown();
            this.material = new System.Windows.Forms.DomainUpDown();
            this.sugar = new System.Windows.Forms.DomainUpDown();
            this.Bicycle.SuspendLayout();
            this.Refreshment.SuspendLayout();
            this.Product.SuspendLayout();
            this.Tshirt.SuspendLayout();
            this.SuspendLayout();
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(13, 13);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(789, 43);
            this.listBox1.TabIndex = 0;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // Bicycle
            // 
            this.Bicycle.Controls.Add(this.button1);
            this.Bicycle.Controls.Add(this.label8);
            this.Bicycle.Controls.Add(this.label7);
            this.Bicycle.Controls.Add(this.label6);
            this.Bicycle.Controls.Add(this.label5);
            this.Bicycle.Controls.Add(this.bicycletype);
            this.Bicycle.Controls.Add(this.weight);
            this.Bicycle.Controls.Add(this.incdimension);
            this.Bicycle.Controls.Add(this.decdimension);
            this.Bicycle.Controls.Add(this.dimension);
            this.Bicycle.Controls.Add(this.incspeeds);
            this.Bicycle.Controls.Add(this.decspeeds);
            this.Bicycle.Controls.Add(this.speeds);
            this.Bicycle.Location = new System.Drawing.Point(13, 261);
            this.Bicycle.Name = "Bicycle";
            this.Bicycle.Size = new System.Drawing.Size(259, 257);
            this.Bicycle.TabIndex = 1;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(54, 189);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(156, 13);
            this.label8.TabIndex = 23;
            this.label8.Text = "type according to selected data";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(115, 136);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(38, 13);
            this.label7.TabIndex = 22;
            this.label7.Text = "weight";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(107, 92);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(54, 13);
            this.label6.TabIndex = 21;
            this.label6.Text = "dimension";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(99, 46);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(63, 13);
            this.label5.TabIndex = 20;
            this.label5.Text = "# of speeds";
            // 
            // bicycletype
            // 
            this.bicycletype.Location = new System.Drawing.Point(3, 205);
            this.bicycletype.Name = "bicycletype";
            this.bicycletype.ReadOnly = true;
            this.bicycletype.Size = new System.Drawing.Size(252, 20);
            this.bicycletype.TabIndex = 15;
            // 
            // weight
            // 
            this.weight.Location = new System.Drawing.Point(4, 152);
            this.weight.Name = "weight";
            this.weight.Size = new System.Drawing.Size(252, 20);
            this.weight.TabIndex = 14;
            this.weight.LostFocus += new System.EventHandler(this.weight_LostFocus);
            // 
            // incdimension
            // 
            this.incdimension.Location = new System.Drawing.Point(187, 108);
            this.incdimension.Name = "incdimension";
            this.incdimension.Size = new System.Drawing.Size(69, 23);
            this.incdimension.TabIndex = 13;
            this.incdimension.Text = "increase";
            this.incdimension.UseVisualStyleBackColor = true;
            this.incdimension.Click += new System.EventHandler(this.incdimension_Click);
            // 
            // decdimension
            // 
            this.decdimension.Location = new System.Drawing.Point(4, 108);
            this.decdimension.Name = "decdimension";
            this.decdimension.Size = new System.Drawing.Size(75, 23);
            this.decdimension.TabIndex = 12;
            this.decdimension.Text = "decrease";
            this.decdimension.UseVisualStyleBackColor = true;
            this.decdimension.Click += new System.EventHandler(this.decdimension_Click);
            // 
            // dimension
            // 
            this.dimension.Enabled = false;
            this.dimension.Location = new System.Drawing.Point(81, 108);
            this.dimension.Name = "dimension";
            this.dimension.Size = new System.Drawing.Size(100, 20);
            this.dimension.TabIndex = 11;
            // 
            // incspeeds
            // 
            this.incspeeds.Location = new System.Drawing.Point(186, 62);
            this.incspeeds.Name = "incspeeds";
            this.incspeeds.Size = new System.Drawing.Size(69, 23);
            this.incspeeds.TabIndex = 10;
            this.incspeeds.Text = "increase";
            this.incspeeds.UseVisualStyleBackColor = true;
            this.incspeeds.Click += new System.EventHandler(this.incspeeds_Click);
            // 
            // decspeeds
            // 
            this.decspeeds.Location = new System.Drawing.Point(3, 62);
            this.decspeeds.Name = "decspeeds";
            this.decspeeds.Size = new System.Drawing.Size(75, 23);
            this.decspeeds.TabIndex = 9;
            this.decspeeds.Text = "decrease";
            this.decspeeds.UseVisualStyleBackColor = true;
            this.decspeeds.Click += new System.EventHandler(this.decspeeds_Click);
            // 
            // speeds
            // 
            this.speeds.Enabled = false;
            this.speeds.Location = new System.Drawing.Point(80, 62);
            this.speeds.Name = "speeds";
            this.speeds.Size = new System.Drawing.Size(100, 20);
            this.speeds.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(380, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(33, 13);
            this.label1.TabIndex = 16;
            this.label1.Text = "name";
            // 
            // Refreshment
            // 
            this.Refreshment.Controls.Add(this.sugar);
            this.Refreshment.Controls.Add(this.button3);
            this.Refreshment.Controls.Add(this.label16);
            this.Refreshment.Controls.Add(this.label14);
            this.Refreshment.Controls.Add(this.label12);
            this.Refreshment.Controls.Add(this.label10);
            this.Refreshment.Controls.Add(this.refreshmentquantity);
            this.Refreshment.Controls.Add(this.quantity);
            this.Refreshment.Controls.Add(this.warranty);
            this.Refreshment.Location = new System.Drawing.Point(543, 261);
            this.Refreshment.Name = "Refreshment";
            this.Refreshment.Size = new System.Drawing.Size(259, 257);
            this.Refreshment.TabIndex = 17;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(113, 136);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(39, 13);
            this.label16.TabIndex = 27;
            this.label16.Text = "sugar?";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(108, 92);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(44, 13);
            this.label14.TabIndex = 25;
            this.label14.Text = "quantity";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(108, 46);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(47, 13);
            this.label12.TabIndex = 24;
            this.label12.Text = "warranty";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(46, 189);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(173, 13);
            this.label10.TabIndex = 25;
            this.label10.Text = "quantity according to selected data";
            // 
            // refreshmentquantity
            // 
            this.refreshmentquantity.Location = new System.Drawing.Point(3, 205);
            this.refreshmentquantity.Name = "refreshmentquantity";
            this.refreshmentquantity.ReadOnly = true;
            this.refreshmentquantity.Size = new System.Drawing.Size(252, 20);
            this.refreshmentquantity.TabIndex = 15;
            // 
            // quantity
            // 
            this.quantity.Location = new System.Drawing.Point(4, 108);
            this.quantity.Name = "quantity";
            this.quantity.Size = new System.Drawing.Size(252, 20);
            this.quantity.TabIndex = 11;
            this.quantity.LostFocus += new System.EventHandler(this.quantity_LostFocus);
            // 
            // warranty
            // 
            this.warranty.Location = new System.Drawing.Point(4, 62);
            this.warranty.Name = "warranty";
            this.warranty.Size = new System.Drawing.Size(252, 20);
            this.warranty.TabIndex = 8;
            this.warranty.LostFocus += new System.EventHandler(this.warranty_LostFocus);
            // 
            // Product
            // 
            this.Product.Controls.Add(this.producttype);
            this.Product.Controls.Add(this.label4);
            this.Product.Controls.Add(this.label3);
            this.Product.Controls.Add(this.label2);
            this.Product.Controls.Add(this.label1);
            this.Product.Controls.Add(this.incstock);
            this.Product.Controls.Add(this.decstock);
            this.Product.Controls.Add(this.incprice);
            this.Product.Controls.Add(this.decprice);
            this.Product.Controls.Add(this.stock);
            this.Product.Controls.Add(this.price);
            this.Product.Controls.Add(this.producer);
            this.Product.Controls.Add(this.name);
            this.Product.Location = new System.Drawing.Point(12, 66);
            this.Product.Name = "Product";
            this.Product.Size = new System.Drawing.Size(790, 189);
            this.Product.TabIndex = 16;
            // 
            // producttype
            // 
            this.producttype.Location = new System.Drawing.Point(4, 166);
            this.producttype.Name = "producttype";
            this.producttype.ReadOnly = true;
            this.producttype.Size = new System.Drawing.Size(783, 20);
            this.producttype.TabIndex = 20;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(378, 117);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(33, 13);
            this.label4.TabIndex = 19;
            this.label4.Text = "stock";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(381, 78);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(30, 13);
            this.label3.TabIndex = 18;
            this.label3.Text = "price";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(370, 39);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 13);
            this.label2.TabIndex = 17;
            this.label2.Text = "producer";
            // 
            // incstock
            // 
            this.incstock.Location = new System.Drawing.Point(718, 133);
            this.incstock.Name = "incstock";
            this.incstock.Size = new System.Drawing.Size(69, 23);
            this.incstock.TabIndex = 7;
            this.incstock.Text = "increase";
            this.incstock.UseVisualStyleBackColor = true;
            this.incstock.Click += new System.EventHandler(this.incstock_Click);
            // 
            // decstock
            // 
            this.decstock.Location = new System.Drawing.Point(4, 133);
            this.decstock.Name = "decstock";
            this.decstock.Size = new System.Drawing.Size(75, 23);
            this.decstock.TabIndex = 6;
            this.decstock.Text = "decrease";
            this.decstock.UseVisualStyleBackColor = true;
            this.decstock.Click += new System.EventHandler(this.decstock_Click);
            // 
            // incprice
            // 
            this.incprice.Location = new System.Drawing.Point(718, 94);
            this.incprice.Name = "incprice";
            this.incprice.Size = new System.Drawing.Size(69, 23);
            this.incprice.TabIndex = 5;
            this.incprice.Text = "increase";
            this.incprice.UseVisualStyleBackColor = true;
            this.incprice.Click += new System.EventHandler(this.incprice_Click);
            // 
            // decprice
            // 
            this.decprice.Location = new System.Drawing.Point(5, 94);
            this.decprice.Name = "decprice";
            this.decprice.Size = new System.Drawing.Size(75, 23);
            this.decprice.TabIndex = 4;
            this.decprice.Text = "decrease";
            this.decprice.UseVisualStyleBackColor = true;
            this.decprice.Click += new System.EventHandler(this.decprice_Click);
            // 
            // stock
            // 
            this.stock.Location = new System.Drawing.Point(81, 133);
            this.stock.Name = "stock";
            this.stock.ReadOnly = true;
            this.stock.Size = new System.Drawing.Size(631, 20);
            this.stock.TabIndex = 3;
            // 
            // price
            // 
            this.price.Location = new System.Drawing.Point(81, 94);
            this.price.Name = "price";
            this.price.ReadOnly = true;
            this.price.Size = new System.Drawing.Size(631, 20);
            this.price.TabIndex = 2;
            // 
            // producer
            // 
            this.producer.Location = new System.Drawing.Point(7, 55);
            this.producer.Name = "producer";
            this.producer.Size = new System.Drawing.Size(783, 20);
            this.producer.TabIndex = 1;
            this.producer.LostFocus += new System.EventHandler(this.producer_LostFocus);
            // 
            // name
            // 
            this.name.Location = new System.Drawing.Point(4, 16);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(783, 20);
            this.name.TabIndex = 0;
            this.name.LostFocus += new System.EventHandler(this.name_LostFocus);
            // 
            // size
            // 
            this.size.Enabled = false;
            this.size.Location = new System.Drawing.Point(81, 62);
            this.size.Name = "size";
            this.size.Size = new System.Drawing.Size(100, 20);
            this.size.TabIndex = 8;
            // 
            // decsize
            // 
            this.decsize.Location = new System.Drawing.Point(4, 62);
            this.decsize.Name = "decsize";
            this.decsize.Size = new System.Drawing.Size(75, 23);
            this.decsize.TabIndex = 9;
            this.decsize.Text = "decrease";
            this.decsize.UseVisualStyleBackColor = true;
            this.decsize.Click += new System.EventHandler(this.decsize_Click);
            // 
            // incsize
            // 
            this.incsize.Location = new System.Drawing.Point(187, 62);
            this.incsize.Name = "incsize";
            this.incsize.Size = new System.Drawing.Size(69, 23);
            this.incsize.TabIndex = 10;
            this.incsize.Text = "increase";
            this.incsize.UseVisualStyleBackColor = true;
            this.incsize.Click += new System.EventHandler(this.incsize_Click);
            // 
            // tshirttype
            // 
            this.tshirttype.Location = new System.Drawing.Point(4, 205);
            this.tshirttype.Name = "tshirttype";
            this.tshirttype.ReadOnly = true;
            this.tshirttype.Size = new System.Drawing.Size(252, 20);
            this.tshirttype.TabIndex = 15;
            // 
            // Tshirt
            // 
            this.Tshirt.Controls.Add(this.material);
            this.Tshirt.Controls.Add(this.color);
            this.Tshirt.Controls.Add(this.button2);
            this.Tshirt.Controls.Add(this.label15);
            this.Tshirt.Controls.Add(this.label13);
            this.Tshirt.Controls.Add(this.label11);
            this.Tshirt.Controls.Add(this.label9);
            this.Tshirt.Controls.Add(this.tshirttype);
            this.Tshirt.Controls.Add(this.incsize);
            this.Tshirt.Controls.Add(this.decsize);
            this.Tshirt.Controls.Add(this.size);
            this.Tshirt.Location = new System.Drawing.Point(278, 261);
            this.Tshirt.Name = "Tshirt";
            this.Tshirt.Size = new System.Drawing.Size(259, 257);
            this.Tshirt.TabIndex = 16;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(110, 136);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(43, 13);
            this.label15.TabIndex = 26;
            this.label15.Text = "material";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(115, 92);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(30, 13);
            this.label13.TabIndex = 24;
            this.label13.Text = "color";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(120, 46);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(25, 13);
            this.label11.TabIndex = 24;
            this.label11.Text = "size";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(52, 189);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(156, 13);
            this.label9.TabIndex = 24;
            this.label9.Text = "type according to selected data";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(87, 231);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 24;
            this.button1.Text = "OK";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(91, 231);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 25;
            this.button2.Text = "OK";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(91, 231);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 27;
            this.button3.Text = "OK";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // color
            // 
            this.color.Items.Add("Red");
            this.color.Items.Add("Blue");
            this.color.Items.Add("Green");
            this.color.Items.Add("Black");
            this.color.Location = new System.Drawing.Point(4, 109);
            this.color.Name = "color";
            this.color.ReadOnly = true;
            this.color.Size = new System.Drawing.Size(252, 20);
            this.color.TabIndex = 27;
            this.color.SelectedItemChanged += new System.EventHandler(this.color_SelectedItemChanged);
            // 
            // material
            // 
            this.material.Items.Add("Wool");
            this.material.Items.Add("Cotton");
            this.material.Items.Add("Polymer");
            this.material.Location = new System.Drawing.Point(4, 152);
            this.material.Name = "material";
            this.material.ReadOnly = true;
            this.material.Size = new System.Drawing.Size(252, 20);
            this.material.TabIndex = 28;
            this.material.SelectedItemChanged += new System.EventHandler(this.material_SelectedItemChanged);
            // 
            // sugar
            // 
            this.sugar.Items.Add("Yes");
            this.sugar.Items.Add("No");
            this.sugar.Location = new System.Drawing.Point(4, 152);
            this.sugar.Name = "sugar";
            this.sugar.ReadOnly = true;
            this.sugar.Size = new System.Drawing.Size(252, 20);
            this.sugar.TabIndex = 29;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(814, 530);
            this.Controls.Add(this.Product);
            this.Controls.Add(this.Bicycle);
            this.Controls.Add(this.Tshirt);
            this.Controls.Add(this.Refreshment);
            this.Controls.Add(this.listBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Bicycle.ResumeLayout(false);
            this.Bicycle.PerformLayout();
            this.Refreshment.ResumeLayout(false);
            this.Refreshment.PerformLayout();
            this.Product.ResumeLayout(false);
            this.Product.PerformLayout();
            this.Tshirt.ResumeLayout(false);
            this.Tshirt.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        public System.Windows.Forms.ListBox listBox1;
        public System.Windows.Forms.Panel Bicycle;
        public System.Windows.Forms.Button incspeeds;
        public System.Windows.Forms.Button incdimension;
        public System.Windows.Forms.TextBox weight;
        public System.Windows.Forms.TextBox bicycletype;
        public System.Windows.Forms.Panel Refreshment;
        public System.Windows.Forms.TextBox refreshmentquantity;
        public System.Windows.Forms.TextBox quantity;
        public System.Windows.Forms.TextBox warranty;
        public System.Windows.Forms.Button decdimension;
        public System.Windows.Forms.TextBox dimension;
        public System.Windows.Forms.Button decspeeds;
        public System.Windows.Forms.TextBox speeds;
        public System.Windows.Forms.Panel Product;
        public System.Windows.Forms.Button incstock;
        public System.Windows.Forms.Button decstock;
        public System.Windows.Forms.Button incprice;
        public System.Windows.Forms.Button decprice;
        public System.Windows.Forms.TextBox stock;
        public System.Windows.Forms.TextBox price;
        public System.Windows.Forms.TextBox producer;
        public System.Windows.Forms.TextBox name;
        public System.Windows.Forms.TextBox size;
        public System.Windows.Forms.Button decsize;
        public System.Windows.Forms.Button incsize;
        public System.Windows.Forms.TextBox tshirttype;
        public System.Windows.Forms.Panel Tshirt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label11;
        public System.Windows.Forms.TextBox producttype;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        public System.Windows.Forms.DomainUpDown color;
        public System.Windows.Forms.DomainUpDown material;
        public System.Windows.Forms.DomainUpDown sugar;

    }
}

