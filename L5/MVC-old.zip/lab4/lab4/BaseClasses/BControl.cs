﻿/**
 * nume si prenume: Manea Vlad
 * email: vlad.manea@info.uaic.ro
 * an: III
 * grupa: 6
 * data realizarii: 31 octombrie 2010
 * data laboratorului: 4 noiembrie 2010
 */

using System;
using System.Collections.Generic;
using lab5.Interfaces;

/**
 * Spatiul de nume pentru clasele de baza necesare laboratorului 5.
 */
namespace lab5.BaseClasses
{
    /**
     * Clasa BControl este utilizata pentru a stabili contractul 
     * intre control si celelalte doua componente: view si model. Am proiectat 
     * controlul sa permita transmiterea de proprietati dinamice spre model. 
     * 
     * Controlul isi cunoaste si modelul, si viewul.
     */
    public class BControl: IControl
    {
        /**
         * Definesc regiunea constructorilor.
         */
        #region "Constructors"

        /**
         * Definesc constructorul care primeste un model, 
         * un control si delegatele pentru actiuni.
         */
        public BControl(IModel _model, IView _view,
            Dictionary<String, DControlSetAction> _actions)
        {
            // setez modelul.
            Model = _model;
            // setez controlul.
            View = _view;
            // setez actiunile.
            actions = _actions;
        }

        /**
         * Definesc constructorul.
         */
        public BControl(Dictionary<String, DControlSetAction> _actions)
        {
            // setez actiunile.
            actions = _actions;
        }

        
        #endregion

        /**
         * Permit doar schimbarea viewului si modelului pentru control.
         */
        #region "Management"

        // retin viewul.
        private IView view = null;

        // retin modelul.
        private IModel model = null;

        /**
         * Permit schimbarea viewului in control.
         */
        public IView View
        {
            set
            {
                // setez viewul acestui control.
                view = value;
            }
        }

        /**
         * Permit schimbarea modelului in control.
         */
        public IModel Model
        {
            set
            {
                // setez modelul acestui control.
                model = value;
            }
        }

        #endregion

        /**
         * Impun sa se poata realiza (desigur, public) actiuni asupra 
         * modelului oricarui control prin control[numeactiune]. Acest lucru
         * este util pentru proprietati dinamice, necunoscute a priori.
         */
        #region "Actions"

        // declar un delegat pentru actiune.
        public delegate void DControlSetAction(Object _parameter, 
            IModel _model, IView _view);

        // retin actiunile
        private Dictionary<String, DControlSetAction> actions = 
            new Dictionary<String, DControlSetAction>();

        /**
         * Cand se apeleaza control[numeactiune] = obiect, controlul va 
         * intelege ca se aplica o actiune si se transmite un obiect 
         * (optional).
         */
        public Object this[string _action]
        {
            set
            {
                // daca actiunea exista in dictionarul de actiuni,
                if (actions.ContainsKey(_action))
                {
                    // realizez actiunea.
                    actions[_action](value, model, view);
                }
            }
        }

        #endregion
    }
}
