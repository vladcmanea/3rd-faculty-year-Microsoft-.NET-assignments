﻿/**
 * nume si prenume: Manea Vlad
 * email: vlad.manea@info.uaic.ro
 * an: III
 * grupa: 6
 * data realizarii: 31 octombrie 2010
 * data laboratorului: 4 noiembrie 2010
 */

using System;
using System.Collections.Generic;
using lab5.Interfaces;

/**
 * Spatiul de nume pentru clasele abstracte necesare laboratorului 5.
 */
namespace lab5.BaseClasses
{
    /**
     * Clasa BView este utilizata pentru a stabili contractul intre
     * view si celelalte doua componente: model si control. Am proiectat 
     * viewul sa permita proprietati dinamice. 
     * 
     * Viewul isi cunoaste si controlul, si modelul care il notifica.
     */
    public class BView: IView
    {
        /**
         * Definesc regiunea constructorilor.
         */
        #region "Constructors"

        /**
         * Definesc constructorul care ia un model, un control
         * si un dictionar de actiuni posibile.
         */
        public BView(IModel _model, IControl _control,
            Dictionary<String, DViewAction> _actions)
        {
            // setez modelul.
            Model = _model;
            // setez controlul.
            Control = _control;
            // setez actiunile.
            actions = _actions;
        }

        #endregion

        /**
         * Impun sa se poata realiza (desigur, public) actiuni asupra 
         * viewului prin view[numeactiune]. Acest lucru este util pentru 
         * proprietati dinamice, necunoscute a priori.
         */
        #region "Actions"

        // declar un delegat pentru actiune.        
        public delegate void DViewAction(Object _object);

        // retin proprietatile intr-o structura de date de tip dictionar.
        // tuplul contine: <valoare_implicita, delegat>
        private Dictionary<String, DViewAction> actions = 
            new Dictionary<String, DViewAction>();

        /**
         * Cand se apeleaza view[numeactiune] = obiect, viewul va 
         * intelege ca se aplica o actiune si se transmite un obiect 
         * (optional). In aceasta metoda din aceasta clasa abstracta 
         * nu se intampla nimic, deoarece actiunile vor fi definite 
         * in clase concrete.
         */
        public Object this[string _action]
        {
            set
            {
                // exista actiunea cu numele respectiv?
                if (actions.ContainsKey(_action))
                {
                    // executa actiunea.
                    actions[_action](value);
                }
            }
        }

        #endregion

        /**
         * Impun modelul de proiectare Observer. Modelul are o lista de
         * elemente ce implementeaza interfata pentru view (IView) care vor
         * fi anuntate dupa ce o proprietate a modelului va fi modificata.
         * Functiile standard sunt cele de adaugare, stergere si notificare.
         * 
         * Se permite doar schimbarea controlului si modelului pentru view.
         */
        #region "Management"

        // retin controlul.
        private IControl control = null;

        // retin modelul.
        private IModel model = null;

        /**
         * Definesc functia de notificare a viewului dinspre model.
         */
        public virtual void UpdateObserver(IModel _model)
        {
            // nu implementez nimic
        }

        /**
         * Permit doar schimbarea controlului in view.
         */
        public IControl Control
        {
            set
            {
                // setez controlul.
                control = value;
                // setez viewul controlului.
                control.View = this;
            }
        }

        /**
         * Permit doar schimbarea modelului in view.
         */
        public IModel Model
        {
            set
            {
                // daca aveam un model de mai demult,
                if (model != null)
                {
                    // ma elimin din lista lui de observatori.
                    model.UnregisterObserver(this);
                }
                // setez modelul nou.
                model = value;
                // inregistrez viewul curent la modelul nou.
                model.RegisterObserver(this);
            }
        }

        #endregion
    }
}
