﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using lab5.Interfaces;

namespace lab5
{
    public partial class Form1 : Form
    {
        ConcreteClasses.ConcreteModels.Bicycle bicycleModel =
            new ConcreteClasses.ConcreteModels.Bicycle("Bicicleta", 10, 0, "BMX", 10, 10, 4);

        ConcreteClasses.ConcreteModels.Tshirt tshirtModel =
            new ConcreteClasses.ConcreteModels.Tshirt("Tricou", 10, 0, "Nike", "Red", "Wool", 40);
                
        ConcreteClasses.ConcreteModels.Refreshment refreshmentModel =
            new ConcreteClasses.ConcreteModels.Refreshment("Suc", 10, 10, "Coke", 2, new DateTime(2010, 10, 1), true);

        IControl control;
        IView view;

        public Form1()
        {
            InitializeComponent();
            Tshirt.Hide();
            Bicycle.Hide();
            Refreshment.Hide();
            Product.Hide();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            listBox1.Items.Add("Bicycle");
            listBox1.Items.Add("Tshirt");
            listBox1.Items.Add("Refreshment");
        }

        // product view delegate
        private static BaseClasses.BView.DViewAction ModTypeProduct =
            delegate(Object _type)
            {
                if (_type is String)
                {
                    Program.MainForm.producttype.Text = (String)_type;
                }
            };

        // bicycle view delegate
        private static BaseClasses.BView.DViewAction ModTypeBicycle =
            delegate(Object _type)
            {
                if (_type is String)
                {
                    Program.MainForm.bicycletype.Text = (String)_type;
                }
            };

        // refreshment view delegate
        private static BaseClasses.BView.DViewAction ModQuantityRefreshment =
            delegate(Object _quantity)
            {
                if (_quantity is String)
                {
                    Program.MainForm.refreshmentquantity.Text = (String)_quantity;
                }
            };

        // tshirt view delegate
        private static BaseClasses.BView.DViewAction ModTypeTshirt =
            delegate(Object _type)
            {
                if (_type is String)
                {
                    Program.MainForm.tshirttype.Text = (String)_type;
                }
            };
        
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Tshirt.Hide();
            Bicycle.Hide();
            Refreshment.Hide();
            Product.Show();
            switch ((String)listBox1.SelectedItem)
            {
                case "Bicycle":
                    Bicycle.Show();
                    control = new ConcreteClasses.ConcreteControls.Bicycle();
                    control.Model = bicycleModel;
                    view = new ConcreteClasses.ConcreteViews.Bicycle(bicycleModel,
                        control, new Dictionary<string,
                            BaseClasses.BView.DViewAction>().Concat(new
                Dictionary<String, BaseClasses.BView.DViewAction>() {
                    {"type", ModTypeBicycle},
                    {"prodtype", ModTypeProduct}
                }).ToDictionary(f => f.Key, f => f.Value));
                    control.View = view;
                    view.UpdateObserver(bicycleModel);
                    weight_LostFocus(weight, new EventArgs());
                    break;
                case "Refreshment":
                    Refreshment.Show();
                    control = new ConcreteClasses.ConcreteControls.Refreshment();
                    control.Model = refreshmentModel;
                    view = new ConcreteClasses.ConcreteViews.Refreshment(refreshmentModel,
                        control, new Dictionary<string,
                            BaseClasses.BView.DViewAction>().Concat(new
                Dictionary<String, BaseClasses.BView.DViewAction>() {
                    {"quantity", ModQuantityRefreshment},
                    {"prodtype", ModTypeProduct}
                }).ToDictionary(f => f.Key, f => f.Value));
                    control.View = view;
                    view.UpdateObserver(refreshmentModel);
                    quantity_LostFocus(quantity, new EventArgs());
                    break;
                case "Tshirt":
                    Tshirt.Show();
                    control = new ConcreteClasses.ConcreteControls.Tshirt();
                    control.Model = tshirtModel;
                    view = new ConcreteClasses.ConcreteViews.Tshirt(tshirtModel,
                        control, new Dictionary<string,
                            BaseClasses.BView.DViewAction>().Concat(new
                Dictionary<String, BaseClasses.BView.DViewAction>() {
                    {"type", ModTypeTshirt},
                    {"prodtype", ModTypeProduct}
                }).ToDictionary(f => f.Key, f => f.Value));
                    control.View = view;
                    view.UpdateObserver(tshirtModel);
                    break;
            }
        }

        private void name_LostFocus(object sender, EventArgs e)
        {
            control["name"] = name.Text.ToString();
        }

        private void producer_LostFocus(object sender, EventArgs e)
        {
            control["producer"] = producer.Text.ToString();
        }

        private void decprice_Click(object sender, EventArgs e)
        {
            control["price"] = false;
        }

        private void incprice_Click(object sender, EventArgs e)
        {
            control["price"] = true;
        }

        private void decstock_Click(object sender, EventArgs e)
        {
            control["stock"] = false;
        }

        private void incstock_Click(object sender, EventArgs e)
        {
            control["stock"] = true;
        }

        private void decspeeds_Click(object sender, EventArgs e)
        {
            control["speeds"] = false;
        }

        private void incspeeds_Click(object sender, EventArgs e)
        {
            control["speeds"] = true;
        }

        private void decdimension_Click(object sender, EventArgs e)
        {
            control["dimension"] = false;
        }

        private void incdimension_Click(object sender, EventArgs e)
        {
            control["dimension"] = true;
        }

        private void decsize_Click(object sender, EventArgs e)
        {
            control["size"] = false;
        }

        private void incsize_Click(object sender, EventArgs e)
        {
            control["size"] = true;
        }

        private void weight_LostFocus(object sender, EventArgs e)
        {
            Double val;
            if (Double.TryParse(weight.Text, out val))
            {
                control["weight"] = val;
            }
            else
            {
                weight.Text = bicycleModel["weight", false].ToString();
            }
        }

        private void warranty_LostFocus(object sender, EventArgs e)
        {
            DateTime val;
            if (DateTime.TryParse(warranty.Text, out val))
            {
                control["warranty"] = val;
            }
            else
            {
                warranty.Text = refreshmentModel["warranty", false].ToString();
            }
        }

        private void quantity_LostFocus(object sender, EventArgs e)
        {
            Double val;
            if (Double.TryParse(quantity.Text, out val))
            {
                control["quantity"] = val;
            }
            else
            {
                quantity.Text = refreshmentModel["sugar", false].ToString();
            }
        }

        private void color_SelectedItemChanged(object sender, EventArgs e)
        {
            if (color.SelectedItem != null)
            {
                control["color"] = color.SelectedItem.ToString();
            }
            else
            {
                control["color"] = color.Items[0].ToString();
            }
        }

        private void material_SelectedItemChanged(object sender, EventArgs e)
        {
            if (material.SelectedItem != null)
            {
                control["material"] = material.SelectedItem.ToString();
            }
            else
            {
                control["material"] = material.Items[0].ToString();
            }
        }

        private void sugar_SelectedItemChanged(object sender, EventArgs e)
        {
            if (sugar.SelectedItem != null)
            {
                if (sugar.SelectedItem.ToString() == "Yes")
                {
                    control["sugar"] = true;
                }
                else
                {
                    control["sugar"] = false;
                }
            }
            else
            {
                control["sugar"] = sugar.Items[0].ToString();
            }
        }
    }
}
