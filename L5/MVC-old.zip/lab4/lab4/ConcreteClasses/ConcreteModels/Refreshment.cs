﻿/**
 * nume si prenume: Manea Vlad
 * email: vlad.manea@info.uaic.ro
 * an: III
 * grupa: 6
 * data realizarii: 31 octombrie 2010
 * data laboratorului: 4 noiembrie 2010
 */

using System;
using System.Collections.Generic;
using System.Linq;
using lab5.Interfaces;

/**
 * Spatiul de nume pentru modelele concrete necesare laboratorului 5.
 */
namespace lab5.ConcreteClasses.ConcreteModels
{
    /**
     * Clasa racoritoare defineste date si delegati pentru produsele de tip racoritoare.
     */
    public class Refreshment : Product
    {
        /**
         * Definesc regiunea constructorilor.
         */
        #region "Constructors"

        /**
         * Constructor cu date primite din clasele derivate din racoritoare.
         * In el se creeaza diferiti delegati pentru set/get zahar, garantie 
         * etc.
         */
        public Refreshment(String _name, Int32 _price, Int32 _stock,
            String _prod, Double _quantity, DateTime _warranty,
            Boolean _sugar, Dictionary<String, Tuple<Object,
            DModelGetAction, DModelSetAction>>
            _propertiesAndActions) :
            base(_name, _price, _stock, _prod, _propertiesAndActions.Concat(new
                Dictionary<String, Tuple<Object, DModelGetAction,
                 DModelSetAction>>() {
                    {"quantity", new Tuple<Object, DModelGetAction, 
                        DModelSetAction>(_quantity, null, SetQuantity)},
                    {"warranty", new Tuple<Object, DModelGetAction, 
                        DModelSetAction>(_warranty, null, SetWarranty)},
                    {"sugar", new Tuple<Object, DModelGetAction, 
                        DModelSetAction>(_sugar, null, SetSugar)}
            }).ToDictionary(e => e.Key, e => e.Value))
        {
            // nu scriu nimic...
        }

        /**
         * Constructor fara date primite din clasele derivate din racoritoare.
         */
        public Refreshment(String _name, Int32 _price, Int32 _stock,
            String _prod, Double _quantity, DateTime _warranty,
            Boolean _sugar)
            : this(_name, _price, _stock, _prod, _quantity,
                _warranty, _sugar, new Dictionary<String, Tuple<Object,
                DModelGetAction, DModelSetAction>>())
        {
            // nu scriu nimic...
        }

        #endregion

        /**
         * Datele uzuale pentru bauturi sunt:
         * - cantitate
         * - warranty
         * - sugar
         */
        #region "Data"

        // creez un delegat pentru setarea cantitatii.
        private static DModelSetAction SetQuantity =
            delegate(Object _quantity, IModel _model)
            {
                // cantitatea este in parametrii normali?
                if (_quantity is Double 
                    && 0.1 <= Double.Parse(_quantity.ToString())
                    && Double.Parse(_quantity.ToString()) <= 2.5)
                {
                    // setez cantitatea.
                    _model["quantity", true] = _quantity;
                }
                else if (_quantity is Double
                    && 0.1 > Double.Parse(_quantity.ToString()))
                {
                    // setez cantitatea.
                    _model["quantity", true] = 0.1;
                }
                else if (_quantity is Double
                    && Double.Parse(_quantity.ToString()) > 2.5)
                {
                    // setez cantitatea.
                    _model["quantity", true] = 2.5;
                }
                else
                {
                    // setez cantitatea implicita.
                    _model["quantity", true] = 1;
                }
            };

        // creez un delegat pentru setarea garantiei.
        private static DModelSetAction SetWarranty =
            delegate(Object _warranty, IModel _model)
            {
                // cantitatea este in parametrii normali?
                if (_warranty is DateTime 
                    && new DateTime(2000, 1, 1) <= 
                    DateTime.Parse(_warranty.ToString())
                    && DateTime.Parse(_warranty.ToString()) <= 
                    new DateTime(2020, 1, 1))
                {
                    // setez garantia.
                    _model["warranty", true] = _warranty;
                }
                else if (_warranty is DateTime
                    && new DateTime(2000, 1, 1) >
                    DateTime.Parse(_warranty.ToString()))
                {
                    // setez garantia.
                    _model["warranty", true] = new DateTime(2000, 1, 1);
                }
                else if (_warranty is DateTime
                    && DateTime.Parse(_warranty.ToString()) >
                    new DateTime(2020, 1, 1))
                {
                    // setez garantia.
                    _model["warranty", true] = new DateTime(2020, 1, 1);
                }
                else
                {
                    // setez garantia implicita.
                    _model["warranty", true] = new DateTime(2020, 1, 1);
                }
            };

        // creez un delegat pentru setarea existentei zaharului.
        private static DModelSetAction SetSugar =
            delegate(Object _sugar, IModel _model)
            {
                if (_sugar is Boolean)
                {
                    // setez existenta zaharului.
                    _model["sugar", true] = _sugar;
                }
                else
                {
                    // setez implicit zaharul.
                    _model["sugar", true] = false;
                }

            };

        #endregion
    }
}