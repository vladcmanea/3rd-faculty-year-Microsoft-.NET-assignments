﻿/**
 * nume si prenume: Manea Vlad
 * email: vlad.manea@info.uaic.ro
 * an: III
 * grupa: 6
 * data realizarii: 31 octombrie 2010
 * data laboratorului: 4 noiembrie 2010
 */

using System;
using System.Collections.Generic;
using System.Linq;
using lab5.Interfaces;

/**
 * Spatiul de nume pentru modelele concrete necesare laboratorului 5.
 */
namespace lab5.ConcreteClasses.ConcreteModels
{
    /**
     * Clasa tricou defineste date si delegati pentru produsele de tip tricou.
     */
    public class Tshirt : Product
    {
        /**
         * Definesc regiunea constructorilor.
         */
        #region "Constructors"

        /**
         * Constructor cu date primite din clasele derivate din tricou.
         * In el se creeaza diferiti delegati pentru set/get culoare, format.
         * etc.
         */
        public Tshirt(String _name, Int32 _price, Int32 _stock, String _prod,
            String _color, String _material, Int32 _size,
            Dictionary<String, Tuple<Object, DModelGetAction,
            DModelSetAction>> _propertiesAndActions) :
            base(_name, _price, _stock, _prod, _propertiesAndActions.Concat(new
                Dictionary<String, Tuple<Object, DModelGetAction,
                 DModelSetAction>>() {
                    {"color", new Tuple<Object, DModelGetAction, 
                        DModelSetAction>(_color, null, SetColor)},
                    {"material", new Tuple<Object, DModelGetAction, 
                        DModelSetAction>(_material, null, SetMaterial)},
                    {"size", new Tuple<Object, DModelGetAction, 
                        DModelSetAction>(_size, null, SetSize)}
            }).ToDictionary(e => e.Key, e => e.Value))
        {
            // nu scriu nimic...
        }

        /**
         * Constructor fara date primite din clasele derivate din tricou.
         */
        public Tshirt(String _name, Int32 _price, Int32 _stock, String _prod,
            String _color, String _material, Int32 _size) :
            this(_name, _price, _stock, _prod, _color, _material, _size,
            new Dictionary<String, Tuple<Object, DModelGetAction,
                DModelSetAction>>())
        {
            // nu scriu nimic...
        }

        #endregion

        /**
         * Datele uzuale pentru tricouri sunt:
         * - culoare
         * - dimensiune
         * - material
         */
        #region "Data"

        // creez un delegat pentru setarea culorii.
        private static DModelSetAction SetColor = 
            delegate(Object _color, IModel _model)
        {
            switch(_color.ToString())
            {
                case "Red":
                case "Blue":
                case "Green":
                    // setez culoarea.
                    _model["color", true] = _color.ToString();
                    break;
                default:
                    // setez culoarea implicita.
                    _model["color", true] = "Black";
                    break;
            }
        };

        // creez un delegat pentru setarea materialului.
        private static DModelSetAction SetMaterial = 
            delegate(Object _material, IModel _model)
        {
            switch(_material.ToString())
            {
                case "Cotton":
                case "Wool":
                    // setez materialul.
                    _model["material", true] = _material.ToString();
                    break;
                default:
                    // setez materialul implicit.
                    _model["material", true] = "Polymer";
                    break;
            }
        };

        // creez un delegat pentru setarea dimensiunii.
        private static DModelSetAction SetSize = 
            delegate(Object _size, IModel _model)
        {
            // dimensiunea este in parametrii normali?
            if (_size is Int32
                && 10 <= Int32.Parse(_size.ToString()) 
                && Int32.Parse(_size.ToString()) <= 50)
            {
                // setez dimensiunea.
                _model["size", true] = _size;
            }
            else if (_size is Int32
                && 10 > Int32.Parse(_size.ToString()))
            {
                // setez dimensiunea.
                _model["size", true] = 10;
            }
            else if (_size is Int32
                && Int32.Parse(_size.ToString()) > 50)
            {
                // setez dimensiunea.
                _model["size", true] = 50;
            }
            else
            {
                // setez dimensiunea implicita.
                _model["size", true] = 30;
            }
        };

        #endregion
    }
}