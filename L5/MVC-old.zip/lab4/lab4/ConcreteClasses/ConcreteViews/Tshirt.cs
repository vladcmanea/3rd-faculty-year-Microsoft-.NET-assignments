﻿/**
 * nume si prenume: Manea Vlad
 * email: vlad.manea@info.uaic.ro
 * an: III
 * grupa: 6
 * data realizarii: 31 octombrie 2010
 * data laboratorului: 4 noiembrie 2010
 */

using System;
using System.Collections.Generic;
using lab5.Interfaces;

/**
 * Spatiul de nume pentru viewurile concrete necesare laboratorului 5.
 */
namespace lab5.ConcreteClasses.ConcreteViews
{
    /**
     * Clasa tricou defineste view pentru tricouri.
     */
    public class Tshirt : Product
    {
        /**
         * Definesc regiunea constructorilor.
         */
        #region "Constructors"

        /**
         * Definesc constructorul care primeste un model si un control.
         */
        public Tshirt(IModel _model, IControl _control, 
            Dictionary<String, DViewAction> _actions):
            base(_model, _control, _actions)
        {
            // nu scriu nimic...
        }

        #endregion

        /**
         * Impun modelul de proiectare Observer. Modelul are o lista de
         * elemente ce implementeaza interfata pentru view (IView) care vor
         * fi anuntate dupa ce o proprietate a modelului va fi modificata.
         * Functiile standard sunt cele de adaugare, stergere si notificare.
         * 
         * Se permite doar schimbarea controlului si modelului pentru view.
         */
        #region "Management"

        /**
         * Definesc functia de notificare a viewului dinspre model.
         */
        public override void UpdateObserver(IModel _model)
        {
            base.UpdateObserver(_model);
            Program.MainForm.color.SelectedItem = _model["color", false].ToString();
            Program.MainForm.size.Text = _model["size", false].ToString();
            Program.MainForm.material.SelectedItem = _model["material", false].ToString();
        }

        #endregion
    }
}
