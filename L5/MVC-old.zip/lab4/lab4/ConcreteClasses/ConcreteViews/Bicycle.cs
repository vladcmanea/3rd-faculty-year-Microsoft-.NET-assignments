﻿/**
 * nume si prenume: Manea Vlad
 * email: vlad.manea@info.uaic.ro
 * an: III
 * grupa: 6
 * data realizarii: 31 octombrie 2010
 * data laboratorului: 4 noiembrie 2010
 */

using System;
using System.Collections.Generic;
using lab5.Interfaces;
using lab5.BaseClasses;

/**
 * Spatiul de nume pentru viewurile concrete necesare laboratorului 5.
 */
namespace lab5.ConcreteClasses.ConcreteViews
{
    /**
     * Clasa bicicleta defineste view pentru bicicleta.
     */
    public class Bicycle : Product
    {
        /**
         * Definesc regiunea constructorilor.
         */
        #region "Constructors"

        /**
         * Definesc constructorul care primeste un model si un control.
         */
        public Bicycle(IModel _model, IControl _control, 
            Dictionary<String, BView.DViewAction> _actions):base(_model, _control, _actions)
        {
            // nu scriu nimic...
        }

        #endregion

        /**
         * Impun modelul de proiectare Observer. Modelul are o lista de
         * elemente ce implementeaza interfata pentru view (IView) care vor
         * fi anuntate dupa ce o proprietate a modelului va fi modificata.
         * Functiile standard sunt cele de adaugare, stergere si notificare.
         * 
         * Se permite doar schimbarea controlului si modelului pentru view.
         */
        #region "Management"

        /**
         * Definesc functia de notificare a viewului dinspre model.
         */
        public override void UpdateObserver(IModel _model)
        {
            base.UpdateObserver(_model);
            Program.MainForm.speeds.Text = _model["speeds", false].ToString();
            Program.MainForm.dimension.Text = _model["dimension", false].ToString();
            Program.MainForm.weight.Text = _model["weight", false].ToString();
        }

        #endregion
    }
}
