﻿/**
 * nume si prenume: Manea Vlad
 * email: vlad.manea@info.uaic.ro
 * an: III
 * grupa: 6
 * data realizarii: 31 octombrie 2010
 * data laboratorului: 4 noiembrie 2010
 */

using System;
using System.Collections.Generic;
using lab5.BaseClasses;
using lab5.Interfaces;

/**
 * Spatiul de nume pentru viewurile concrete necesare laboratorului 5.
 */
namespace lab5.ConcreteClasses.ConcreteViews
{
    /**
     * Clasa produs defineste view pentru produse.
     */
    public class Product : BView
    {
        /**
         * Definesc regiunea constructorilor.
         */
        #region "Constructors"

        /**
         * Definesc constructorul care primeste un model si un control.
         */
        public Product(IModel _model, IControl _control):
            base(_model, _control, new Dictionary<String, DViewAction>())
        {
            // nu scriu nimic...
        }

        /**
         * Definesc constructorul care primeste un model, un control si
         * o serie de actiuni.
         */
        public Product(IModel _model, IControl _control, 
            Dictionary<String, DViewAction> _actions) :
            base(_model, _control, _actions)
        {
            // nu scriu nimic...
        }

        #endregion

        /**
         * Impun modelul de proiectare Observer. Modelul are o lista de
         * elemente ce implementeaza interfata pentru view (IView) care vor
         * fi anuntate dupa ce o proprietate a modelului va fi modificata.
         * Functiile standard sunt cele de adaugare, stergere si notificare.
         * 
         * Se permite doar schimbarea controlului si modelului pentru view.
         */
        #region "Management"

        /**
         * Definesc functia de notificare a viewului dinspre model.
         */
        public override void UpdateObserver(IModel _model)
        {
            base.UpdateObserver(_model);
            Program.MainForm.name.Text = _model["name", false].ToString();
            Program.MainForm.producer.Text = _model["producer", false].ToString();
            Program.MainForm.stock.Text = _model["stock", false].ToString();
            Program.MainForm.price.Text = _model["price", false].ToString();
        }

        #endregion
    }
}
