﻿/**
 * nume si prenume: Manea Vlad
 * email: vlad.manea@info.uaic.ro
 * an: III
 * grupa: 6
 * data realizarii: 31 octombrie 2010
 * data laboratorului: 4 noiembrie 2010
 */

using System;
using System.Collections.Generic;
using System.Linq;
using lab5.Interfaces;

/**
 * Spatiul de nume pentru controlurile concrete necesare laboratorului 5.
 */
namespace lab5.ConcreteClasses.ConcreteControls
{
    /**
     * Clasa racoritoare defineste actiuni pentru toate racoritoarele.
     */
    public class Refreshment : Product
    {
        /**
         * Definesc regiunea constructorilor.
         */
        #region "Constructors"

        /**
         * Definesc constructorul care primeste un model, 
         * un control si delegatele pentru actiuni de la subclase.
         */
        public Refreshment(IModel _model, IView _view,
            Dictionary<String, DControlSetAction> _actions)
            : base(_model,
                _view, _actions.Concat(new
                Dictionary<String, DControlSetAction>() {
                    {"warranty", ModWarranty},
                    {"sugar", ModSugar},
                    {"quantity", ModQuantity}
            }).ToDictionary(e => e.Key, e => e.Value))
        {
            // nu scriu nimic...
        }

        /**
         * Definesc constructorul care primeste un model, 
         * un control, dar nu si delegatele pentru actiuni.
         */
        public Refreshment(IModel _model, IView _view)
            : this(_model, _view, new Dictionary<String, 
                DControlSetAction>())
        {
            // nu scriu nimic...
        }

        /**
         * Definesc constructorul fara parametri.
         */
        public Refreshment()
            : base(new Dictionary<String, 
                DControlSetAction>().Concat(new
                Dictionary<String, DControlSetAction>() {
                    {"warranty", ModWarranty},
                    {"sugar", ModSugar},
                    {"quantity", ModQuantity}
            }).ToDictionary(e => e.Key, e => e.Value))
        {
            // nu scriu nimic...
        }

        
        #endregion

        /**
         * Declar constrangerile Business.
         */
        #region "Business"

        /**
         * Definesc un delegat pentru setarea cantitatii.
         * Actualizez datele pentru putin, suficient sau cancer.
         */
        private static DControlSetAction ModQuantity =
            delegate(Object _quantity, IModel _model, IView _view)
            {
                // greutatea este numar real?
                if (_quantity is Double)
                {
                    // setez noua greutate.
                    _model["quantity", false] = 
                        Double.Parse(_quantity.ToString());
                }
                // testez actiunea pentru view.
                if (Double.Parse(_model["quantity", false].ToString()) < 0.25)
                {
                    // consider prea putin.
                    _view["quantity"] = "insuficient";
                }
                else if (Double.Parse(_model["quantity", false].ToString()) <= 2.0)
                {
                    // consider optim.
                    _view["quantity"] = "ok";
                }
                else
                {
                    if (_model["sugar", false].ToString() == "True")
                    {
                        // consider cancer :)
                        _view["quantity"] = "cancer cu zahar";
                    }
                    else
                    {
                        // consider cancer :)
                        _view["quantity"] = "cancer fara zahar";
                    }
                }
            };

        /**
         * Definesc un delegat pentru setarea zaharului.
         */
        private static DControlSetAction ModSugar =
            delegate(Object _sugar, IModel _model, IView _view)
            {
                // zaharul este boolean?
                if (_sugar is Boolean)
                {
                    // setez noul zahar.
                    _model["sugar", false] = 
                        Boolean.Parse(_model["sugar", false].ToString());
                    // testez actiunea pentru view.
                    if (Double.Parse(_model["quantity", false].ToString()) < 0.25)
                    {
                        // consider prea putin.
                        _view["quantity"] = "insuficient";
                    }
                    else if (Double.Parse(_model["quantity", false].ToString()) <= 2.0)
                    {
                        // consider optim.
                        _view["quantity"] = "ok";
                    }
                    else
                    {
                        if (_model["sugar", false].ToString() == "True")
                        {
                            // consider cancer :)
                            _view["quantity"] = "cancer cu zahar";
                        }
                        else
                        {
                            // consider cancer :)
                            _view["quantity"] = "cancer fara zahar";
                        }
                    }
                }
            };
        
        /**
         * Definesc un delegat pentru modificarea termenului de garantie.
         */
        private static DControlSetAction ModWarranty =
            delegate(Object _warranty, IModel _model, IView _view)
            {
                // garantia este o data?
                if (_warranty is DateTime)
                {
                    // setez noua garantie.
                    _model["warranty", false] = 
                        DateTime.Parse(_warranty.ToString());
                }
            };

        #endregion
    }
}
