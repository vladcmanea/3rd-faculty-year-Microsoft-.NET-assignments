﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Http;
using System.Runtime.Remoting;
using System.Collections;
using RemoteInterfaces;

namespace Client
{
    public partial class Client : Form
    {
        public Client()
        {
            InitializeComponent();
        }

        private void Client_Load(object sender, EventArgs e)
        {
                BinaryServerFormatterSinkProvider serverProvider = new BinaryServerFormatterSinkProvider();
                serverProvider.TypeFilterLevel = System.Runtime.Serialization.Formatters.TypeFilterLevel.Full;
                BinaryClientFormatterSinkProvider clientProvider = new BinaryClientFormatterSinkProvider();
                HttpChannel channel = new HttpChannel(null, clientProvider, serverProvider);
                ChannelServices.RegisterChannel((IChannel)channel, false);
                ICustomerData customerData = (ICustomerData)Activator.GetObject(typeof(RemoteInterfaces.ICustomerData),
                    "http://localhost:3456/CustomerData.soap");

                // call CreateCustomer()
                ICustomer customer = customerData.CreateCustomer();
                customer.Name = "Codrin Ditu";
                customer.ID = 1;
                listBox1.Items.Add("customerData.createCustomer()");
                listBox2.Items.Add(customer);
                listBox1.Items.Add("customer.Hello()");
                listBox2.Items.Add(customer.Hello("Salut :)"));

                // call CreateCustomer(string, int)
                ICustomer customerTVA = customerData.CreateCustomer("Vlad Tudose", 1);
                listBox1.Items.Add("customerData.createCustomer(name, id)");
                listBox2.Items.Add(customerTVA);
                listBox1.Items.Add("customer.Hello()");
                listBox2.Items.Add(customerTVA.Hello("2SAT"));

                // call GetFromDatabase()
                ArrayList fromDB = customerData.GetFromDatabase();
                int i = 1;
                foreach (var person in fromDB)
                {
                    listBox1.Items.Add("customerData.GetFromDatabase() | result #" + i);
                    listBox2.Items.Add(person);
                    ++i;
                }

                // call AddToCollection
                customerData.AddToCollection(customerTVA);
                ArrayList fromSRV = customerData.GetCustomers;
                i = 1;
                foreach (var person in fromSRV)
                {
                    listBox1.Items.Add("customerData.GetCustomers() | result #" + i);
                    listBox2.Items.Add(person);
                    ++i;
                }

                // call GetOrder
                String theOrder = customerData.GetOrder();
                listBox1.Items.Add("customerData.GetOrder()");
                listBox2.Items.Add(theOrder);
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            listBox2.SelectedIndex = ((ListBox)sender).SelectedIndex;
        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            listBox1.SelectedIndex = ((ListBox)sender).SelectedIndex;
        }
    }
}
