﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Http;
using RemoteObjects;
using System.Runtime.Remoting;
using System.Collections;

namespace Client
{
    public partial class Client : Form
    {
        public Client()
        {
            InitializeComponent();
        }

        private void Client_Load(object sender, EventArgs e)
        {
            try
            {
                BinaryServerFormatterSinkProvider serverProvider = new BinaryServerFormatterSinkProvider();
                serverProvider.TypeFilterLevel = System.Runtime.Serialization.Formatters.TypeFilterLevel.Full;
                BinaryClientFormatterSinkProvider clientProvider = new BinaryClientFormatterSinkProvider();
                HttpChannel channel = new HttpChannel(null, clientProvider, serverProvider);
                ChannelServices.RegisterChannel((IChannel)channel, false);
                Object remoteObject = Activator.GetObject(typeof(RemoteObjects.CustomerData),
                    "http://localhost:4527/CustomerData.soap");
                CustomerData customerData = (CustomerData)remoteObject;

                // call CreateCustomer()
                Customer customer = customerData.CreateCustomer();
                customer.Name = "Codrin Ditu";
                customer.ID = 1;
                listBox1.Items.Add("customerData.createCustomer()");
                listBox2.Items.Add(customer);
                listBox1.Items.Add("customer.Hello()");
                listBox2.Items.Add(customer.Hello("Salut :)"));

                // call CreateCustomer(string, int)
                Customer customerTVA = customerData.CreateCustomer("Vlad Tudose", 1);
                listBox1.Items.Add("customerData.createCustomer(name, id)");
                listBox2.Items.Add(customerTVA);
                listBox1.Items.Add("customer.Hello()");
                listBox2.Items.Add(customerTVA.Hello("2SAT"));

                // call GetFromDatabase()
                ArrayList fromDB = customerData.GetFromDatabase();
                int i = 1;
                foreach (var person in fromDB)
                {
                    listBox1.Items.Add("customerData.GetFromDatabase() | result #" + i);
                    listBox2.Items.Add(person);
                    ++i;
                }

                // call AddToCollection
                customerData.AddToCollection(customerTVA);
                ArrayList fromSRV = customerData.GetCustomers;
                i = 1;
                foreach (var person in fromSRV)
                {
                    listBox1.Items.Add("customerData.GetCustomers() | result #" + i);
                    listBox2.Items.Add(person);
                    ++i;
                }

                // call GetOrder
                String theOrder = customerData.GetOrder();
                listBox1.Items.Add("customerData.GetOrder()");
                listBox2.Items.Add(theOrder);
            }
            catch (Exception exception)
            {
                CustomerData customerData2 = new CustomerData();

                // call CreateCustomer()
                Customer customer2 = customerData2.CreateCustomer();
                customer2.Name = "Codrin Ditu";
                customer2.ID = 1;
                listBox1.Items.Add("customerData.createCustomer()");
                listBox2.Items.Add(customer2);
                listBox1.Items.Add("customer.Hello()");
                listBox2.Items.Add(customer2.Hello("Salut :)"));

                // call CreateCustomer(string, int)
                Customer customerTVA = customerData2.CreateCustomer("Vlad Tudose", 1);
                listBox1.Items.Add("customerData.createCustomer(name, id)");
                listBox2.Items.Add(customerTVA);
                listBox1.Items.Add("customer.Hello()");
                listBox2.Items.Add(customerTVA.Hello("2SAT"));

                // call GetFromDatabase()
                ArrayList fromDB = customerData2.GetFromDatabase();
                int i = 1;
                foreach (var person in fromDB)
                {
                    listBox1.Items.Add("customerData.GetFromDatabase() | result #" + i);
                    listBox2.Items.Add(person);
                    ++i;
                }

                // call AddToCollection
                customerData2.AddToCollection(customerTVA);
                ArrayList fromSRV = customerData2.GetCustomers;
                i = 1;
                foreach (var person in fromSRV)
                {
                    listBox1.Items.Add("customerData.GetCustomers() | result #" + i);
                    listBox2.Items.Add(person);
                    ++i;
                }

                // call GetOrder
                String theOrder = customerData2.GetOrder();
                listBox1.Items.Add("customerData.GetOrder()");
                listBox2.Items.Add(theOrder);
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            listBox2.SelectedIndex = ((ListBox)sender).SelectedIndex;
        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            listBox1.SelectedIndex = ((ListBox)sender).SelectedIndex;
        }
    }
}
