﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RemoteObjects;
using RemoteInterfaces;

namespace RemoteObjects
{
    public class Customer: MarshalByRefObject, ICustomer
    {
        public string Name
        {
            get;
            set;
        }

        public int ID
        {
            get;
            set;
        }

        public Customer()
        {
            ID = 0;
            Name = "N/A";
        }

        public Customer(string name, int id)
        {
            this.Name = name;
            this.ID = id;
        }

        public override string ToString()
        {
            return "{Name: " + Name + ", ID: " + ID + "}";
        }

        public string Hello(string msg)
        {
            return "Message " + msg + " from: " + this.ToString();
        }
    }
}
