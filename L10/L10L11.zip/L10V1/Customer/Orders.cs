﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RemoteObjects
{
    public class Orders
    {
        public string GetOrder()
        {
            return "Comanda 1";
        }
    }
}
