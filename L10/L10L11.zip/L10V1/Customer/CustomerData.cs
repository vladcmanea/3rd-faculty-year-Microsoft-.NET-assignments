﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace RemoteObjects
{
    public class CustomerData: MarshalByRefObject
    {
        ArrayList _listCustomer = new ArrayList();
        public CustomerData()
        {
        }

        public Customer CreateCustomer()
        {
            return new Customer();
        }

        public Customer CreateCustomer(string name, int id)
        {
            return new Customer(name, id);
        }

        public ArrayList GetFromDatabase()
        {
            ArrayList supposeFromDB = new ArrayList()
            {
                new Customer("Ionel Albesteanu", 3),
                new Customer("Andrei Livadariu", 4)
            };

            supposeFromDB.Add(new Customer("Paul Diac", 1));
            supposeFromDB.Add(new Customer("Adrian Airinei", 1));

            return supposeFromDB;
        }

        public bool AddToCollection(Customer _cust)
        {
            if (_cust != null)
            {
                this._listCustomer.Add(_cust);
                return true;
            }
            return false;
        }

        public ArrayList GetCustomers
        {
            get
            {
                ArrayList customers = new ArrayList();
                foreach (Customer customer in _listCustomer)
                {
                    customers.Add(customer);
                }
                return customers;
            }
        }

        public string GetOrder()
        {
            Orders cda = new Orders();
            return cda.GetOrder();
        }
    }
}
