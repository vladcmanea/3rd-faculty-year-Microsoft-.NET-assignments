﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace RemoteObjects
{
    public class CustomerData : MarshalByRefObject
    {
        ArrayList _listCustomer = new ArrayList();
        public CustomerData()
        {
            throw new NotSupportedException("Metoda nu poate fi rulata local");
        }

        public Customer CreateCustomer()
        {
            throw new NotSupportedException("Metoda nu poate fi rulata local");
        }

        public Customer CreateCustomer(string name, int id)
        {
            throw new NotSupportedException("Metoda nu poate fi rulata local");
        }

        public ArrayList GetFromDatabase()
        {
            throw new NotSupportedException("Metoda nu poate fi rulata local");
        }

        public bool AddToCollection(Customer _cust)
        {
            throw new NotSupportedException("Metoda nu poate fi rulata local");
        }

        public ArrayList GetCustomers
        {
            get
            {
                throw new NotSupportedException("Metoda nu poate fi rulata local");
            }
        }

        public string GetOrder()
        {
            throw new NotSupportedException("Metoda nu poate fi rulata local");
        }
    }
}
