﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RemoteObjects
{
    public class Customer : MarshalByRefObject
    {
        public string Name
        {
            get
            {
                throw new NotSupportedException("Metoda nu poate fi rulata local");
            }
            set
            {
                throw new NotSupportedException("Metoda nu poate fi rulata local");
            }
        }

        public int ID
        {
            get
            {
                throw new NotSupportedException("Metoda nu poate fi rulata local");
            }
            set
            {
                throw new NotSupportedException("Metoda nu poate fi rulata local");
            }
        }

        public Customer()
        {
            throw new NotSupportedException("Metoda nu poate fi rulata local");
        }

        public Customer(string name, int id)
        {
            throw new NotSupportedException("Metoda nu poate fi rulata local");
        }

        public override string ToString()
        {
            throw new NotSupportedException("Metoda nu poate fi rulata local");
        }

        public string Hello(string msg)
        {
            throw new NotSupportedException("Metoda nu poate fi rulata local");
        }
    }
}