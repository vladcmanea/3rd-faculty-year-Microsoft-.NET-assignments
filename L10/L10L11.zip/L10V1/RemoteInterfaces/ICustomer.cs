﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RemoteInterfaces
{
    public interface ICustomer
    {
        string Name
        {
            get;
            set;
        }

        int ID
        {
            get;
            set;
        }

        string ToString();

        string Hello(string msg);
    }
}
