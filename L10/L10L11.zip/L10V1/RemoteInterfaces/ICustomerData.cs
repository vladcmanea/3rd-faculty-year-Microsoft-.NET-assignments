﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace RemoteInterfaces
{
    public interface ICustomerData
    {
        ICustomer CreateCustomer();

        ICustomer CreateCustomer(string name, int id);

        ArrayList GetFromDatabase();

        bool AddToCollection(ICustomer _cust);

        ArrayList GetCustomers
        {
            get;
        }

        string GetOrder();
    }
}
